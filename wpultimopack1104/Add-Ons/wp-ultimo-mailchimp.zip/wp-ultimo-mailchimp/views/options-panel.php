<style>
#wu-product-data ul.wc-tabs li.mailchimp_options a:before, 
#wu-coupon-data ul.wc-tabs li.mailchimp_options a:before, 
.wu ul.wc-tabs li.mailchimp_options a:before {
  content: "\f465";
}
</style>

<div id="wu_mailchimp" class="panel wu_options_panel">

  <?php if (WU_Settings::get_setting('wu-mailchimp-api-key')) : ?>

  <?php
  /**
   * Check if we need to select a list or lists and groups
   */
  if (WU_Settings::get_setting('wu-mailchimp-integration-type') == 'lists') : ?>

    <div class="options_group">

      <p class="form-field">
        <label class="form-field-full">
          <?php _e('Select below the lists you want the users that select this plan to be added to. You can select more than one list.', 'wp-ultimo'); ?><br>
          <strong><?php _e('Leave this blank to use the default list selected on WP Ultimo Settings > Add-ons Settings > MailChimp.', 'wp-ultimo'); ?></strong>
        </label>
      </p>

    </div>

    <div class="options_group">

      <p class="form-field _wu-mailchimp-list_field">
        
        <label for="wu-mailchimp-list">
          <?php _e('Mailchimp Lists', 'wu-mailchimp'); ?>
        </label>

          <input id="wu-mailchimp-list" value="<?php echo $plan->mailchimp_lists; ?>" type="text" name="mailchimp_lists" class="regular-text" placeholder="<?php _e('Select the Target Lists', 'wp-ultimo'); ?>">

        <span class="description"></span>

      </p>

    </div>

  <?php else : ?>

    <div class="options_group">

      <p class="form-field">
        <label class="form-field-full">
          <?php _e('Select the list you want to add the users of this plans to when they sign-up. You can also select the list groups that user will belong to.', 'wp-ultimo'); ?><br>
          <strong><?php _e('Leave this blank to use the default list selected on WP Ultimo Settings > Add-ons Settings > MailChimp.', 'wp-ultimo'); ?></strong>
        </label>
      </p>

    </div>

    <div class="options_group">

      <p class="form-field _wu-mailchimp-list_field">
        
        <label for="wu-mailchimp-list">
          <?php _e('Mailchimp List', 'wu-mailchimp'); ?>
        </label>

          <input id="wu-mailchimp-default-single-list" value="<?php echo $plan->mailchimp_lists; ?>" type="text" name="mailchimp_lists" class="regular-text" placeholder="<?php _e('Select the Target List', 'wp-ultimo'); ?>">

        <span class="description"></span>

      </p>

    </div>

    <div class="options_group">

      <p class="form-field _wu-mailchimp-list_field">
        
        <label for="wu-mailchimp-list">
          <?php _e('Mailchimp List Groups', 'wu-mailchimp'); ?>
        </label>

          <input id="wu-mailchimp-groups" value="<?php echo $plan->mailchimp_groups; ?>" type="text" name="mailchimp_groups" class="regular-text" placeholder="<?php _e('Select the Target Groups', 'wp-ultimo'); ?>">

        <span class="description"></span>

      </p>

    </div>

    <?php endif; ?>

  <?php else : ?>

  <div class="options_group">

    <p class="form-field">
      <label class="form-field-full">
        <?php printf(__('You need to enter a MailChimp API Key on the add-ons settings page in order for this integration to work. <a href="%s">%s</a>.', 'wp-mailchimp'), network_admin_url('admin.php?page=wp-ultimo&wu-tab=addons-settings'), __('Go to the Settings &rarr;', 'wp-mailchimp')); ?>
      </label>
    </p>

  </div>

  <?php endif; ?>
  
</div>
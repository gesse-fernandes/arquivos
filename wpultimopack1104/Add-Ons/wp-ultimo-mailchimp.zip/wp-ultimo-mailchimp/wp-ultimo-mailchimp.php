<?php
/**
 * Plugin Name: WP Ultimo: Mailchimp Integration
 * Description: Integrate your WP Ultimo network to your Mailchimp. You can link certain plans to Mailchimp Lists and automatically add subscribers to those lists on signup.
 * Plugin URI: http://wpultimo.com
 * Text Domain: wu-mailchimp
 * Version: 1.1.0
 * Author: Arindo Duque - NextPress
 * Author URI: http://nextpress.co/
 * Copyright: Arindo Duque, NextPress
 * Network: true
 */

if (!defined('ABSPATH')) {
  exit; // Exit if accessed directly.
}

if (!class_exists('WP_Ultimo_Mailchimp')) :

/**
 * Here starts our plugin.
 */
class WP_Ultimo_Mailchimp {
  
  /**
   * Version of the Plugin
   * @var string
   */
  public $version = '1.1.0';
  
  /**
   * Makes sure we are only using one instance of the plugin
   * @var object WP_Ultimo_Mailchimp
   */
  public static $instance;

  /**
   * API Key for Mailchimp
   */
  public $api_key = '';

  /**
   * Returns the instance of WP_Ultimo_Mailchimp
   * @return object A WP_Ultimo_Mailchimp instance
   */
  public static function get_instance() {

    if (null === self::$instance) self::$instance = new self();

    return self::$instance;
    
  } // end get_instance;

  /**
   * Initializes the plugin
   */
  public function __construct() {

    load_plugin_textdomain('wu-mailchimp', false, dirname(plugin_basename(__FILE__)) . '/lang');

    // Updater
    require_once $this->path('inc/class-wu-addon-updater.php');

    /**
     * @since 1.2.0 Creates the updater
     * @var WU_Addon_Updater
     */
    $updater = new WU_Addon_Updater('wp-ultimo-mailchimp', __('WP Ultimo: MailChimp Integration', 'wu-mailchimp'), __FILE__);

    // Run Rorest, run!
    $this->hooks();

  } // end construct;

  /**
   * Return url to some plugin subdirectory
   * @return string Url to passed path
   */
  public function path($dir) {
    return plugin_dir_path(__FILE__).'/'.$dir;
  }

  /**
   * Return url to some plugin subdirectory
   * @return string Url to passed path
   */
  public function url($dir) {
    return plugin_dir_url(__FILE__).'/'.$dir;
  }
  
  /**
   * Return full URL relative to some file in assets
   * @return string Full URL to path
   */
  public function get_asset($asset, $assetsDir = 'img') {
    return $this->url("assets/$assetsDir/$asset");
  }

  /**
   * Render Views
   * @param string $view View to be rendered.
   * @param Array $vars Variables to be made available on the view escope, via extract().
   */
  public function render($view, $vars = false) {

    // Make passed variables available
    if (is_array($vars)) extract($vars);

    // Load our view
    include $this->path("views/$view.php");

  }

  /** 
   * Add the hooks we need to make this work
   */
  public function hooks() {

    /**
     * Admin init
     */
    add_action('admin_init', array($this, 'init_plugin'));

    /**
     * Add custom settings
     */
    add_action('wu_settings_sections', array($this, 'add_settings'));

    /**
     * Plan - Advanced Tab to select the list
     */
    add_filter('wu_plans_advanced_options_tabs', array($this, 'add_plan_tab'));

    add_action('wu_plans_advanced_options_after_panels', array($this, 'add_plan_tab_content'));

    add_action('wu_save_plan', array($this, 'save_plan_lists'));
    
    /**
     * Ajax Server the List options
     */
    add_action('wp_ajax_wu_query_mailchimp_lists', array($this, 'serve_mailchimp_list_options'));
    add_action('wp_ajax_wu_query_mailchimp_groups', array($this, 'serve_mailchimp_group_options'));

    /**
     * Registration Hook
     */
    add_action('wp_ultimo_registration', array($this, 'register_user_to_lists'), 10, 3);

    /**
     * Change Plan Hook
     */
    add_action('wu_subscription_change_plan', array($this, 'change_plan_list'), 10, 3);
    
    /**
     * Delete Account Hook
     */
    add_action('wpmu_delete_user', array($this, 'remove_user'), -100);

  } // end hooks;

  public function init_plugin() {

    /** Register Core Script */
    wp_register_script('wu-mailchimp', $this->get_asset('wu-mailchimp.min.js', 'js'), array('jquery'), $this->version);

  } // end init_plugin;

  /**
   * Is single list
   *
   * @since 1.2.0
   * @return boolean
   */
  public function is_single_list() {

    return WU_Settings::get_setting('wu-mailchimp-integration-type') == 'list-and-group';

  } // end is_single_list;

  /**
   * Checks if we also need to subscribe on the default list/group
   *
   * @since 1.2.0
   * @return bool
   */
  public function should_double_subscribe() {

    return WU_Settings::get_setting('wu-mailchimp-double-subscribe', false);

  } // end should_double_subscribe;

  /**
   * Change plans, also should chnage the list from mailchimp
   * @param  WU_Subscription $subscription Subscription of the user
   * @param  WU_Plan         $new_plan     New plan of the user
   * @return void               
   */
  public function change_plan_list($subscription, $new_plan, $current_plan) {

    if ($subscription) {

      // Remove from previous lists
      $this->remove_from_previous_lists($subscription, $current_plan);

      // Add to the new ones
      $this->register_user_to_lists(null, $subscription->user_id, array());

    } // end if;

  } // end change_plan_list;

  /**
   * Get the selected cancel list
   *
   * @return array
   */
  public function get_mailchimp_canceled_list() {

    $cancel_lists = $this->is_single_list() 
      ? WU_Settings::get_setting('wu-mailchimp-default-cancel-list', '') 
      : WU_Settings::get_setting('wu-mailchimp-cancel-lists', '');

    return explode(',', (string) $cancel_lists);

  } // end get_mailchimp_canceled_list;

  /**
   * Change the user to the new list of removed users
   * 
   * @param interger $user_id ID of the new user
   */
  public function remove_user($user_id) {

    // Get Subscription and plan
    $subscription = wu_get_subscription($user_id);
    $user         = get_user_by('id', $user_id);

    if ($subscription) {

      $plan = $subscription->get_plan();

      if (!$plan) return;

      // Remove from previous lists
      $this->remove_from_previous_lists($subscription, $plan);

      // Add to the removed users lists
      $lists = $this->get_mailchimp_canceled_list();

      $user_data = array(
        'email_address' => $user->user_email,
        'status'        => 'subscribed',
      );

      // If we have groups, add to groups
      if ($this->is_single_list()) {

        $groups = explode(',', WU_Settings::get_setting('wu-mailchimp-cancel-groups', ''));

        $user_data['interests'] = array();

        foreach ($groups as $group_id) {

          $user_data['interests'][$group_id] = true;

        } // end foreach;

      } // end if;

      foreach ($lists as $list_id) {

        $url = "lists/$list_id/members";

        $results = $this->send_mailchimp_call($url, $user_data, 'POST');

      } // end foreach;

    } // end if;

  } // end remove_user;

  /**
   * Remove user from previous lists
   * @param  WU_Subscription $subscription Subscription
   * @param  WU_Plan         $plan         WU Plan Object
   * @return void
   */
  public function remove_from_previous_lists($subscription, $plan) {

    // /lists/{list_id}/members/{subscriber_hash}
    $user = get_user_by('id', $subscription->user_id);

    if ($plan->mailchimp_lists) {

      $lists = explode(',', (string) WU_Settings::get_setting('wu-mailchimp-default-lists'));

    } else {

      $lists = explode(',', $plan->mailchimp_lists);

    } // end if;

    // Remove the user from those lists
    foreach ($lists as $list_id) {

      $subscriber_hash = md5($user->user_email);

      $url = "lists/$list_id/members/$subscriber_hash";

      $results = $this->send_mailchimp_call($url, array(), 'DELETE');

    } // end foreach;

  } // end remove_from_previous_lists;

  /**
   * Returns a list of the default lists depending on the type of Mailchimp integration
   *
   * @since 1.2.0
   * @return array
   */
  public function get_default_lists() {

    $lists = $this->is_single_list() 
      ? explode(',', (string) WU_Settings::get_setting('wu-mailchimp-default-single-list'))
      : explode(',', (string) WU_Settings::get_setting('wu-mailchimp-default-lists'));

    return array_filter($lists);

  } // end get_default_lists;

  /**
   * If this option is enabled, adds the user to the default list as well as the plan list and group
   *
   * @since 1.2.0
   * @param array $user_data
   * @return void
   */
  public function add_to_default_list_and_group($user_data) {

    if (!$this->should_double_subscribe()) return;

    $lists = $this->get_default_lists();

    // If we have groups, add to groups
    if ($this->is_single_list()) {

      $groups = array_filter(explode(',', (string) WU_Settings::get_setting('wu-mailchimp-groups')));

      $user_data['interests'] = array();

      foreach ($groups as $group_id) {

        $user_data['interests'][$group_id] = true;

      } // end foreach;

    } // end if;

    foreach ($lists as $list_id) {

      $url = "lists/$list_id/members";

      $results = $this->send_mailchimp_call($url, $user_data, 'POST');

    } // end foreach;

  } // end add_to_default_list_and_group;

  /**
   * Returns the mailchimp lists for a given plan
   *
   * @param WU_Plan $plan
   * @return array
   */
  public function get_plan_mailchimp_lists($plan) {

    if (empty($plan->mailchimp_lists)) {

      $lists = $this->get_default_lists();

    } else {

      $lists = explode(',', (string) $plan->mailchimp_lists);

    } // end if;

    return array_filter($lists);

  } // end get_mailchimp_lists;

  /**
   * Returns the Mailchimp groups for a given plan
   *
   * @param WU_Plan $plan
   * @return array
   */
  public function get_plan_mailchimp_groups($plan) {

    if (!$this->is_single_list()) return array();

    if (empty($plan->mailchimp_groups)) {

      $groups = explode(',', (string) WU_Settings::get_setting('wu-mailchimp-groups'));

    } else {

      $groups = explode(',', (string) $plan->mailchimp_groups);

    } // end if;

    return array_filter($groups);

  } // end get_plan_mailchimp_groups;

  /**
   * Registers users to the Mailchimp lists when they signup
   * @param  interger $site_id   The ID of the newly created site
   * @param  interget $user_id   Id of the user
   * @param  array    $transient Transient information
   * @return void
   */
  public function register_user_to_lists($site_id, $user_id, $transient) {

    // Get Subscription and plan
    $subscription = wu_get_subscription($user_id);

    if (!$subscription) return;

    $plan         = $subscription->get_plan();
    $user         = get_user_by('id', $user_id);

    if (!$plan) return;

    // Check for plan or default lists
    $lists = $this->get_plan_mailchimp_lists($plan);

    $user_data = array(
      'email_address' => $user->user_email,
      'status'        => 'subscribed',
    );

    // Add to the defualt lists if we need to
    $this->add_to_default_list_and_group($user_data);

    // If we have groups, add to groups
    if ($this->is_single_list()) {

      $groups = $this->get_plan_mailchimp_groups($plan);

      $user_data['interests'] = array();

      foreach ($groups as $group_id) {

        $user_data['interests'][$group_id] = true;

      } // end foreach;

    } // end if;

    foreach ($lists as $list_id) {

      $url = "lists/$list_id/members";

      $results = $this->send_mailchimp_call($url, $user_data, 'POST');

    } // end foreach;

  } // end register_user_to_lists;

  /**
   * Save the lists to the plan
   * @param  WU_Plan $plan Plan Object
   * @return void
   */
  public function save_plan_lists($plan) {

    if (is_a($plan, 'WU_Plan') && isset($_POST['mailchimp_lists'])) {

      update_post_meta($plan->id, 'wpu_mailchimp_lists', $_POST['mailchimp_lists']);

    } // end if;

    if (is_a($plan, 'WU_Plan') && isset($_POST['mailchimp_groups'])) {

      update_post_meta($plan->id, 'wpu_mailchimp_groups', $_POST['mailchimp_groups']);

    } // end if;

  } // end save_plan_lists;

  /**
   * Serve the list options retrieved from the api
   * @return string
   */
  public function serve_mailchimp_list_options() {

    $lists = $this->send_mailchimp_call('lists');

    if (isset($_GET['lists']) && $_GET['lists']) {

      $selected = explode(',', $_GET['lists']);

      $filtered_lists = array_filter($lists->lists, function($item) use ($selected) {

        if (in_array($item->id, $selected)) {
          
          return true;

        }

      });

      echo $this->is_single_list() ? json_encode(array_shift($filtered_lists)) : json_encode($filtered_lists); die;

    } // end if;

    echo json_encode($lists->lists); die;

  } // end serve_mailchimp_list_options;

  /**
   * Serve Mailchimp Groups options
   *
   * @return void
   */
  public function serve_mailchimp_group_options() {

    // Get the List ID
    $list_id = isset($_GET['list_id']) && $_GET['list_id'] ? $_GET['list_id'] : false;

    if (!$list_id) wp_send_json(array());

    $groups = $this->get_groups_for_list($list_id);

    if (isset($_GET['groups']) && $_GET['groups']) {

      $selected = explode(',', $_GET['groups']);

      $groups_list = array();

      foreach ($groups as $group) {
        foreach ($group['children'] as $child) {
          $groups_list[] = $child;
        }
      }

      $filtered_groups = array_filter($groups_list, function($item) use ($selected) {

        if (in_array($item->id, $selected)) {
          
          return true;

        }

      });

      echo json_encode($filtered_groups); die;

    } // end if;

    wp_send_json($groups);

  }

  public function get_groups_for_list($list_id) {

    $results = array();

    // First, we need the categories
    $categories = $this->send_mailchimp_call("lists/$list_id/interest-categories");

    if (!$categories->categories) return array();

    // Loop the categories to find the interests, but save the title
    foreach ($categories->categories as $category) {

      // https://us11.api.mailchimp.com/3.0/lists/7dbd00104d/interest-categories/ccbf0d9cdc/interests
      $interests = $this->send_mailchimp_call("lists/$list_id/interest-categories/$category->id/interests");

      if (!$interests->interests) continue;

      $results[] = array(
        'text'     => $category->title, 
        'children' => $interests->interests,
      );

    }

    return $results;

  } // end get_groups_for_list;

  /**
   * Add the MailChimp tab to the advanced options on the edit plan page
   * @param array $tabs Tabs of the advanced options
   */
  public function add_plan_tab($tabs) {

    $tabs['mailchimp'] = __('Mailchimp', 'wu-mailchimp');

    return $tabs;

  } // end add_plan_tab;

  /**
   * Adds the HTMl markep of the Tab we added
   * @param WU_Plan $plan Plan Object
   */
  public function add_plan_tab_content($plan) {

    WP_Ultimo()->enqueue_select2();

    wp_enqueue_script('wu-mailchimp');

    $this->render('options-panel', array(
      'plan' => $plan
    ));

  } // end add_plan_tab_content;

  /**
   * Adds the custom settings to the add-on section of our settings page on WP Ultimo
   * @param array $sections Sections;
   */
  function add_settings($sections) {

    if (function_exists('wp_enqueue_script') && is_network_admin()) {

      WP_Ultimo()->enqueue_select2();

      wp_enqueue_script('wu-mailchimp');

    } // end if;

    /**
     * Check if section for add-ons already exists
     */

    if (!isset($sections['addons-settings'])) {

      $sections['addons-settings'] = array(
        'title'  => __('Add-on Settings', 'wu-mailchimp'),
        'desc'   => __('Add-on Settings', 'wu-mailchimp'),
        'fields' => array(
          'advanced'        => array(
            'title'         => __('Add-on Settings', 'wu-ptm'),
            'desc'          => __('Settings added by add-ons installed.', 'wu-ptm'),
            'type'          => 'heading',
          ),
        )
      );

    } // end if;

    /**
     * Add the fields
     */
    $sections['addons-settings']['fields']['wu-mailchimp-options'] = array(
      'title'          => __('WP Ultimo: Mailchimp Integration Options', 'wu-mailchimp'),
      'desc'           => __('', 'wu-mailchimp'),
      'type'           => 'heading_collapsible',
    );

    $sections['addons-settings']['fields']['wu-mailchimp-api-key'] = array(
      'title'         => __('Mailchimp API Key', 'wu-mailchimp'),
      'desc'          => __('Don\'t have a Mailchimp API Key?', 'wu-mailchimp') .' '. sprintf('<a href="%s" target="_blank">%s</a>', 'https://kb.mailchimp.com/accounts/management/about-api-keys/#Find-or-Generate-Your-API-Key', __('Click here to know how to get one &rarr;', 'wu-mailchimp')),
      'tooltip'       => '',
      'type'          => 'text',
      'default'       => '',
    );

    $sections['addons-settings']['fields']['wu-mailchimp-integration-type'] = array(
      'title'         => __('Integration Type', 'wp-ultimo'),
      'desc'          => __('You can either select different lists to be used for each plan, or use a single list and segment using groups.', 'wp-ultimo'),
      'type'          => 'select',
      'default'       => 'lists',
      'tooltip'       => '',
      'options'       => array(
        'lists'          => __('Use Multiple Lists', 'wp-ultimo'),
        'list-and-group' => __('Use Single List + Multiple Groups', 'wp-ultimo'),
      )
    );

    $sections['addons-settings']['fields']['wu-mailchimp-default-lists'] = array(
      'title'         => __('Mailchimp Default Lists', 'wu-mailchimp'),
      'desc'          => __('Select the default Mailchimp lists to be used when no specific list is chosen on a certain plan.'),
      'tooltip'       => '',
      'type'          => 'text',
      'default'       => '',
      'require'       => array('wu-mailchimp-integration-type' => 'lists'),
    );

    $sections['addons-settings']['fields']['wu-mailchimp-cancel-lists'] = array(
      'title'         => __('Mailchimp Canceled Accounts Lists', 'wu-mailchimp'),
      'desc'          => __('Select the Mailchimp lists to be used when a user cancels his or her account.'),
      'tooltip'       => '',
      'type'          => 'text',
      'default'       => '',
      'require'       => array('wu-mailchimp-integration-type' => 'lists'),
    );

    $sections['addons-settings']['fields']['wu-mailchimp-default-single-list'] = array(
      'title'         => __('Mailchimp Default List', 'wu-mailchimp'),
      'desc'          => __('Select the default Mailchimp lists to be used when no specific list is chosen on a certain plan.'),
      'tooltip'       => '',
      'type'          => 'text',
      'default'       => '',
      'require'       => array('wu-mailchimp-integration-type' => 'list-and-group'),
    );

    $sections['addons-settings']['fields']['wu-mailchimp-groups'] = array(
      'title'         => __('Mailchimp Default Groups', 'wu-mailchimp'),
      'desc'          => __('Select which groups of the above list we should add to the user to when plans do not override this.'),
      'tooltip'       => '',
      'type'          => 'text',
      'default'       => '',
      'require'       => array('wu-mailchimp-integration-type' => 'list-and-group'),
    );

    $sections['addons-settings']['fields']['wu-mailchimp-default-cancel-list'] = array(
      'title'         => __('Mailchimp Canceled Accounts List', 'wu-mailchimp'),
      'desc'          => __('Select the Mailchimp list to be used when a user cancels his or her account.'),
      'tooltip'       => '',
      'type'          => 'text',
      'default'       => '',
      'require'       => array('wu-mailchimp-integration-type' => 'list-and-group'),
    );

    $sections['addons-settings']['fields']['wu-mailchimp-cancel-groups'] = array(
      'title'         => __('Mailchimp Canceled Accounts List Groups', 'wu-mailchimp'),
      'desc'          => __('Select which groups of the above list we should add to the user email to when he closes his or her account.'),
      'tooltip'       => '',
      'type'          => 'text',
      'default'       => '',
      'require'       => array('wu-mailchimp-integration-type' => 'list-and-group'),
    );

    $sections['addons-settings']['fields']['wu-mailchimp-double-subscribe'] = array(
      'title'         => __('Double Subscription', 'wu-mailchimp'),
      'desc'          => __('Check to subscribe to both the default and per-plan lists when possible.', 'wu-mailchimp'),
      'tooltip'       => '',
      'type'          => 'checkbox',
      'default'       => 0,
    );

    return $sections;

  } // end add_settings;

  /**
   * Send Mailchimp Call
   * @param  string $url  URL to the endpoint
   * @param  array  $data Data to post to Mailchimp
   * @return object       Result from the call
   */
  public function send_mailchimp_call($url, $data = array(), $req = 'GET') {

    /**
     * Get the API Key
     */
    $this->api_key = WU_Settings::get_setting('wu-mailchimp-api-key');

    /** @var string Get the data center */
    $data_center = substr($this->api_key, strpos($this->api_key, '-') + 1);

    /** @var string URL with the correct datacenter */
    $url = "https://$data_center.api.mailchimp.com/3.0/$url";

    /** @var string Encode the data array */
    $json_data = json_encode($data);

    /** @var object Instantiate the curl caller */
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    curl_setopt($ch, CURLOPT_USERAGENT, 'PHP-MCAPI/2.0');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

    if ($req == 'GET') {

      // Nothing

    } else if ($req == 'POST') {

      curl_setopt($ch, CURLOPT_POST, true);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);

    } else {

      curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
      curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $req);

    }
    
    curl_setopt($ch, CURLOPT_USERPWD, "user:" . $this->api_key);   

    /** Return the results */
    $result = curl_exec($ch);

    curl_close($ch);

    return json_decode($result);

  } // end send_mailchimp_call;

} // end WP_Ultimo_Mailchimp;

/**
 * Initialize the Plugin
 */
add_action('plugins_loaded', 'wu_mailchimp', 1);

function WP_Ultimo_Mailchimp() {

  return WP_Ultimo_Mailchimp::get_instance();

}

function wu_mailchimp() {

  if (!class_exists('WP_Ultimo')) return; // We require WP Ultimo, baby

  // Set global
  $GLOBALS['WP_Ultimo_Mailchimp'] = WP_Ultimo_Mailchimp();

}

endif;
=== WP Ultimo: Mailchimp Integration ===
Contributors: aanduque
Requires at least: 4.4

Integrate your WP Ultimo network to your Mailchimp. You can link certain plans to Mailchimp Lists and automatically add subscribers to those lists on signup.

== Description ==

WP Ultimo: Mailchimp Integration

Integrate your WP Ultimo network to your Mailchimp. You can link certain plans to Mailchimp Lists and automatically add subscribers to those lists on signup.

== Installation ==

1. Upload 'wp-ultimo-mailchimp' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in your WordPress Network Admin

== Changelog ==

Version 1.1.0 - 03/05/2018
- Fixed: Lots of minor issues and bugs;
- Added: Possibility to use a single list and segment via MailChimp groups;

Version 1.0.0 - Initial Release
=== WP Ultimo: VAT ===
Contributors: aanduque
Requires at least: 4.5
Tested up to: 5.1.1
Requires PHP: 5.6
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds VAT support to the WP Ultimo tax system for countries that are part of the EU

== Description ==

WP Ultimo: VAT

Adds VAT support to the WP Ultimo tax system for countries that are part of the EU

== Installation ==

1. Upload 'wp-ultimo-vat' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in your WordPress Network Admin

== Changelog ==

0.0.1 - Initial Release - Alpha
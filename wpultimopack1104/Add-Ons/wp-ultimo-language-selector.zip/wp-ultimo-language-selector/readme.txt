=== WP Ultimo: Language Selector on Sign-up ===
Contributors: aanduque
Requires at least: 4.5
Tested up to: 5.2.2
Requires PHP: 5.6
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add a language selector field to the sign-up flow.

== Description ==

WP Ultimo: Language Selector on Sign-up

Add a language selector field to the sign-up flow.

== Installation ==

1. Upload 'wp-ultimo-language-selector' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in your WordPress Network Admin

== Changelog ==

Version 0.0.3 - 20/08/2019

* Fixed: Language Selector appearing empty on first run in non-english WordPress versions;

Version 0.0.2 - 17/07/2019

* Fixed: Small bug fixes.

0.0.1 - Initial Release (25/02/2019)
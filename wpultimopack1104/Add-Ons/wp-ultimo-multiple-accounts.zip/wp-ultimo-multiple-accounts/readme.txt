=== WP Ultimo: Multiple Accounts ===
Contributors: aanduque
Requires at least: 4.4
Tested up to: 5.1
Requires PHP: 5.6

Allows for users to create accounts on the main network (WP Ultimo), even if the user has used that email to create an account on one of the subsites before.

== Description ==

WP Ultimo: Multiple Accounts

Allows for users to create accounts on the main network (WP Ultimo), even if the user has used that email to create an account on one of the subsites before.

Supports:
- WooCommerce account creation;

== Installation ==

1. Upload 'wp-ultimo-multiple-accounts' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in your WordPress Network Admin

== Changelog ==

Version 1.1.2 - 20/06/2019

* Improved: Support to WooCommerce registration from account page as well;

Version 1.0.2 - 07/12/2018

* Fixed: Updated the metadata URL for updates;

Version 1.0.1 - 15/07/2018

* Fixed: Small bugs;

1.0.0 - Initial Release
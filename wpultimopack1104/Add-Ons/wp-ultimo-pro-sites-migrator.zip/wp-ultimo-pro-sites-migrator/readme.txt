=== WP Ultimo: Pro Sites Migrator ===
Contributors: aanduque
Requires at least: 4.5
Tested up to: 5.2.2
Requires PHP: 5.6
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Migrates your premium network from Pro Sites to WP Ultimo

== Description ==

WP Ultimo: Pro Sites Migrator

Migrates your premium network from Pro Sites to WP Ultimo

== Installation ==

1. Upload 'wp-ultimo-pro-sites-migrator' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in your WordPress Network Admin

== Changelog ==

Version 0.0.3

* Improved: Added a new strategy to try to figure out the real site owner by using the admin email before looping through site users;

Version 0.0.2

* Fixed: Blog Template images not being generated;
* Fixed: Template step not being automatically enabled when blog templates were present;

0.0.1 - Initial Release
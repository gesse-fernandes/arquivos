<?php
/**
 * Plugin Name: WP Ultimo: Pro Sites Migrator
 * Description: Migrates your premium network from Pro Sites to WP Ultimo. Requires WP Ultimo 1.9.11.
 * Plugin URI: http://wpultimo.com/addons
 * Text Domain: wu-ps-migrator
 * Version: 0.0.3
 * Author: Arindo Duque - NextPress
 * Author URI: http://nextpress.co/
 * Copyright: Arindo Duque, NextPress
 * Network: true
 */

if (!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
} // end if;

if (!class_exists('WP_Ultimo_PS_Migrator')) :

	/**
	 * Here starts our plugin.
	 */
	class WP_Ultimo_PS_Migrator {

		/**
		 * Version of the Plugin
		 *
		 * @var string
		 */
		public $version = '0.0.3';

		/**
		 * Makes sure we are only using one instance of the plugin
		 *
		 * @var object WP_Ultimo_PS_Migrator
		 */
		public static $instance;

		/**
		 * Returns the instance of WP_Ultimo_PS_Migrator
		 *
		 * @return object A WP_Ultimo_PS_Migrator instance
		 */
		public static function get_instance() {

			if (null === self::$instance) {

				self::$instance = new self();

			} // end if;

			return self::$instance;

		} // end get_instance;

		/**
		 * Initializes the plugin
		 */
		public function __construct() {

			// Set the plugins_path
			$this->plugins_path = plugin_dir_path(__DIR__);

			// Load the text domain
			load_plugin_textdomain('wu-ps-migrator', false, dirname(plugin_basename(__FILE__)) . '/lang');

			// Updater
			require_once $this->path('inc/class-wu-addon-updater.php');

			/**
			 * @since 0.0.1 Creates the updater
			 * @var WU_Addon_Updater
			 */
			$updater = new WU_Addon_Updater('wp-ultimo-pro-sites-migrator', __('WP Ultimo: Pro Sites Migrator', 'wu-ps-migrator'), __FILE__);

			/**
			 * Require Files
			 */

			// Run Forest, run!
			$this->hooks();

		} // end __construct;

		/**
		 * Return url to some plugin subdirectory
		 *
		 * @return string Url to passed path
		 */
		public function path($dir) {

			return plugin_dir_path(__FILE__) . '/' . $dir;

		} // end path;

		/**
		 * Return url to some plugin subdirectory
		 *
		 * @return string Url to passed path
		 */
		public function url($dir) {

			return plugin_dir_url(__FILE__) . '/' . $dir;

		} // end url;

		/**
		 * Return full URL relative to some file in assets
		 *
		 * @return string Full URL to path
		 */
		public function get_asset($asset, $assets_dir = 'img') {

			return $this->url("assets/$assets_dir/$asset");

		} // end get_asset;

		/**
		 * Render Views
		 *
		 * @param string $view View to be rendered.
		 * @param Array  $vars Variables to be made available on the view escope, via extract().
		 */
		public function render($view, $vars = false) {

			// Make passed variables available
			if (is_array($vars)) {

				extract($vars); // phpcs:ignore

			} // end if;

			// Load our view
			include $this->path("views/$view.php");

		} // end render;

		/**
		 * Add the hooks we need to make this work
		 */
		public function hooks() {

			$this->load_migrators_and_checkers();

			$this->add_warning_notice();

		} // end hooks;

		/**
		 * Load the migrators and checkers
		 *
		 * @since 1.0.0
		 * @return void
		 */
		public function load_migrators_and_checkers() {

			/**
			 * Settings Migrator
			 */
			require_once $this->path('inc/migrators/class-wups-settings-migrator.php');

			/**
			 * Plan Migrator
			 */
			require_once $this->path('inc/migrators/class-wups-plan-migrator.php');

			/**
			 * Coupon Migrator (Done √)
			 */
			require_once $this->path('inc/migrators/class-wups-coupon-migrator.php');

			/**
			 * Subscriptions Migrator
			 *
			 * Pro Sites do things a bit differently than we do, so they don't have Subscriptions per se.
			 * Because of this, we need consolidate different sites into a single subscription.
			 * We also need to add the mappings for all the sites and to refresh the disk space.
			 */
			require_once $this->path('inc/migrators/class-wups-subscription-migrator.php');

			/**
			 * Incompatibility Checkers
			 */
			require_once $this->path('inc/checkers/class-wups-incompat-plugins.php');

			/**
			 * Loads the setup
			 */
			require_once $this->path('inc/setup/class-wups-setup.php');

		} // end load_migrators_and_checkers;

		/**
		 * Adds a message to the Network admin with a link to the Migrator Interface.
		 *
		 * @since 0.0.1
		 * @return void
		 */
		public function add_warning_notice() {

			$message  = __('The <strong>Pro Sites &rarr; WP Ultimo Migrator</strong> is active on your Network.', 'wu-ps-migrator') . ' ';
			$message .= sprintf(__('%1$sClick here%2$s to access the migrator or %3$shere%4$s to deactivate it, if you already migrated your data.', 'wu-ps-migrator'), '<a href="' . network_admin_url('admin.php?page=wups-migrator') . '">', '</a>', '<a href="' . network_admin_url('plugins.php') . '">', '</a>');

			WP_Ultimo()->add_message($message, 'warning', true);

		} // end add_warning_notice;

	} // end class WP_Ultimo_PS_Migrator;

	/**
	 * Returns the active instance of the plugin
	 *
	 * @return mixed
	 */
	function WP_Ultimo_PS_Migrator() { // phpcs:ignore

		return WP_Ultimo_PS_Migrator::get_instance();

	} // end WP_Ultimo_PS_Migrator;

	/**
	 * Initialize the Plugin
	 */
	add_action('plugins_loaded', 'wu_ps_migrator_init', 1);

	/**
	 * We require WP Ultimo, so we need it
	 *
	 * @since 0.0.1
	 * @return void
	 */
	function wu_ps_migrator_requires_ultimo() { ?>

  <div class="notice notice-warning"> 
    <p><?php _e('WP Ultimo: Pro Sites Migrator requires WP Ultimo to run. Install and active WP Ultimo to use WP Ultimo: Pro Sites Migrator.', 'wu-ps-migrator'); ?></p>
  </div>

		<?php
    }  // end wu_ps_migrator_requires_ultimo;

	/**
	 * Initializes the plugin
	 *
	 * @since 0.0.1
	 * @return mixed
	 */
	function wu_ps_migrator_init() {

		if (!class_exists('WP_Ultimo')) {

			return add_action('network_admin_notices', 'wu_ps_migrator_requires_ultimo');

		} // end if;

		if (!version_compare(WP_Ultimo()->version, '1.9.11', '>=')) {

			return WP_Ultimo()->add_message(__('WP Ultimo: Pro Sites Migrator requires WP Ultimo version 1.9.11 and WPMU DEV\'s Pro Sites to be active ', 'wu-ps-migrator'), 'warning', true);

		} // end if;

		// Set global
		$GLOBALS['WP_Ultimo_PS_Migrator'] = WP_Ultimo_PS_Migrator();

	} // end wu_ps_migrator_init;

endif;

<?php
/**
 * Settings Migrator
 *
 * Takes Pro Sites settings and transfers them to WP Ultimo.
 *
 * @since       0.0.1
 * @author      Arindo Duque
 * @category    Migrator
 * @package     WP_Ultimo_PS_Migrator/Migrators/Settings
 * @version     0.0.1
 */

if (!defined('ABSPATH')) {
	exit;
} // end if;

/**
 * Migrates the Settings from Pro Sites to WP Ultimo
 *
 * @since 0.0.1
 */
class WU_PS_Settings_Migrator {

	/**
	 * Makes sure we are only using one instance of the class
	 *
	 * @since 1.8.2
	 * @var WU_PS_Settings_Migrator
	 */
	public static $instance;

	/**
	 * Keeps a copy of the plugin version for caching purposes
	 *
	 * @since 1.8.2
	 * @var string
	 */
	public $version = '1.0.0';

	/**
	 * Returns the instance of WP_Ultimo
	 *
	 * @return object A WU_PS_Settings_Migrator instance
	 */
	public static function get_instance() {

		if (null === self::$instance) {

			self::$instance = new self();

		} // end if;

		return self::$instance;

	} // end get_instance;

	/**
	 * Initializes the class
	 */
	public function __construct() {

	}  // end __construct;

	/**
	 * Get settings option by key
	 *
	 * @since 0.0.1
	 * @param string $key Key.
	 * @return mixed
	 */
	public function get_ps_saved_setting($key) {

		global $psts;

		return $psts->get_setting($key);

	}  // end get_ps_saved_setting;

	/**
	 * Gets all the templates on Pro Sites
	 *
	 * @since 0.0.1
	 * @return array
	 */
	public function get_ps_templates() {

		return function_exists('nbt_get_model') ? nbt_get_model()->get_templates() : array();

	} // end get_ps_templates;


	/**
	 * Gets all the settings on Pro Sites
	 *
	 * @since 0.0.1
	 * @return array
	 */
	public function get_ps_settings() {

		$new_settings = array();

		$new_settings['currency_symbol'] = $this->get_ps_saved_setting('currency');

		switch ($this->get_ps_saved_setting('curr_symbol_position')) {

			case '1':
				$new_settings['currency_position'] = '%s%v';
				break;
			case '2':
				$new_settings['currency_position'] = '%s %v';
				break;
			case '3':
				$new_settings['currency_position'] = '%v%s';
				break;
			case '4':
				$new_settings['currency_position'] = '%v %s';
				break;
			default:
				$new_settings['currency_position'] = '%s%v';

		} // end switch;

		switch ($this->get_ps_saved_setting('curr_decimal')) {

			case '0':
				$new_settings['precision'] = '0';
				break;
			case '1':
				$new_settings['precision'] = '2';
				break;
			default:
				$new_settings['precision'] = '2';

		} // end switch;

		$gateways_enabled = $this->get_ps_saved_setting('gateways_enabled');

		if (!empty($gateways_enabled)) {

				$new_settings['active_gateway']['manual'] = in_array('ProSites_Gateway_Manual', $gateways_enabled);

				$new_settings['active_gateway']['stripe'] = in_array('ProSites_Gateway_Stripe', $gateways_enabled);

				$new_settings['active_gateway']['paypal'] = in_array('ProSites_Gateway_PayPalExpressPro', $gateways_enabled);

		} // end if;

		// paypal
		if ($new_settings['active_gateway']['paypal']) {

			$new_settings['paypal_username'] = $this->get_ps_saved_setting('pypl_api_user');

			$new_settings['paypal_pass'] = $this->get_ps_saved_setting('pypl_api_pass');

			$new_settings['paypal_signature'] = $this->get_ps_saved_setting('pypl_api_sig');

		} // end if;

		// stripe
		if ($new_settings['active_gateway']['stripe']) {

			$new_settings['stripe_api_pk'] = $this->get_ps_saved_setting('stripe_publishable_key');

			$new_settings['stripe_api_sk'] = $this->get_ps_saved_setting('stripe_secret_key');

		} // end if;

		$enabled_periods = $this->get_ps_saved_setting('enabled_periods');

		if (!empty($enabled_periods)) {

				$new_settings['enable_price_1'] = in_array(1, $enabled_periods);

				$new_settings['enable_price_3'] = in_array(3, $enabled_periods);

				$new_settings['enable_price_12'] = in_array(12, $enabled_periods);

		} // end if;

		// Enable registration
		$new_settings['enable_signup'] = $this->get_ps_saved_setting('show_signup');

		// Enable Multiple sites per user
		$new_settings['enable_multiple_sites'] = $this->get_ps_saved_setting('multiple_signup');

		// Trial days
		$new_settings['trial'] = !is_null($this->get_ps_saved_setting('trial_days')) ? $this->get_ps_saved_setting('trial_days') : '0';

		$new_settings['enable_coupon_codes'] = $this->get_ps_saved_setting('coupons_enabled');

		return $new_settings;

	} // end get_ps_settings;

	/**
	 * Convert PS Settings to WP Ultimo Settings
	 *
	 * @since 0.0.1
	 * @param array $new_settings New settings.
	 * @return array
	 */
	public function convert_to_wu_settings($new_settings) {

		WU_Logger::add('pro-sites-migrator', '  ');
		WU_Logger::add('pro-sites-migrator', 'Migrating Settings:');

		foreach ($new_settings as $setting => $value) {

			WU_Logger::add('pro-sites-migrator', sprintf('|-- Setting the value of %s to %s', $setting, $value));

		} // end foreach;

		WP_Ultimo()->saveOption('settings', array_merge(WU_Settings::get_settings(), $new_settings));

		WU_Logger::add('pro-sites-migrator', 'Finished Migrating Settings =)');

		return array(
			'added'   => array(),
			'updated' => $new_settings,
			'failed'  => array(),
		);

	} // end convert_to_wu_settings;

	/**
	 * Convert a PS Templates to WP Ultimo Templates
	 *
	 * @since 0.0.1
	 * @param array $templates Templates.
	 * @return array
	 */
	public function convert_to_wu_templates($templates) {

		WU_Logger::add('pro-sites-migrator', '  ');
		WU_Logger::add('pro-sites-migrator', 'Migrating Blog Templates:');

		if (count($templates)) {

			// Enable template selection
			WU_Settings::save_setting('allow_template', 1);

		} // end if;
		
		$new_templates = WU_Settings::get_setting('templates', array());

		foreach ($templates as $key => $value) {

			$wu_template = new WU_Site_Template($value['blog_id']);

			// Adds the data
			$wu_template->set_attributes(array(
				'blogname'        => $value['name'],
				'blogdescription' => $value['description'],
				'template_img'    => isset($value['options']['screenshot']) ? $value['options']['screenshot'] : false,
			));

			$cats = array();

			foreach ($value['options']['post_category'] as $key => $cat) {

				$cats[] = $cat;

			} // end foreach;

			$wu_template->wu_categories = implode(', ', array_unique($cats));

			$wu_template->save();

			// check available templates in wu settings
			WU_Settings::save_setting('templates', array_replace(WU_Settings::get_setting('templates', array()), array($wu_template->id => '1')) );

			WU_Logger::add('pro-sites-migrator', sprintf('|-- Migrating Blog Template %s', $value['name']));

		} // end foreach;

		WU_Logger::add('pro-sites-migrator', 'No errors migrating Blog Templates.');

		return array(
			'added'   => array(),
			'updated' => $templates,
			'failed'  => array(),
		);

	}  // end convert_to_wu_templates;

} // end class WU_PS_Settings_Migrator;

/**
 * Returns the singleton
 */
function WU_PS_Settings_Migrator() { // phpcs:ignore

	return WU_PS_Settings_Migrator::get_instance();

} // end WU_PS_Settings_Migrator;

// Initialize
WU_PS_Settings_Migrator();

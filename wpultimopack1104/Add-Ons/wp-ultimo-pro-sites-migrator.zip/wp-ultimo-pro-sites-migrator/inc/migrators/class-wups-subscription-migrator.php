<?php
/**
 * Subscriptions Migrator
 *
 * Takes Pro Sites subscriptions and transfers them to WP Ultimo.
 *
 * @since       0.0.1
 * @author      Arindo Duque
 * @category    Migrator
 * @package     WP_Ultimo_PS_Migrator/Migrators/Subscriptions
 * @version     0.0.1
 */

if (!defined('ABSPATH')) {
	exit;
} // end if;

/**
 * Migrates the Subscription from Pro Sites to WP Ultimo
 *
 * @since 0.0.1
 */
class WU_PS_Subscription_Migrator {

	/**
	 * Makes sure we are only using one instance of the class
	 *
	 * @since 1.8.2
	 * @var WU_PS_Subscription_Migrator
	 */
	public static $instance;

	/**
	 * Keeps a copy of the plugin version for caching purposes
	 *
	 * @since 1.8.2
	 * @var string
	 */
	public $version = '1.0.0';

	/**
	 * Returns the instance of WP_Ultimo
	 *
	 * @return object A WU_PS_Subscription_Migrator instance
	 */
	public static function get_instance() {

		if (null === self::$instance) {

			self::$instance = new self();

		} // end if;

		return self::$instance;

	} // end get_instance;

	/**
	 * Initializes the class
	 */
	public function __construct() { }  // end __construct;

	/**
	 * Check if WPMUDEV's domain mapping is active.
	 *
	 * @since 0.0.1
	 * @return boolean
	 */
	public function is_wpmudev_domain_mapping_active() {

		return class_exists('Domainmap_Plugin') && defined('SUNRISE');

	} // end is_wpmudev_domain_mapping_active;

	/**
	 * Returns all Pro Sites on the platform.
	 *
	 * @since 0.0.1
	 * @return array
	 */
	public function get_all_pro_sites() {

		global $wpdb;

		$sites = $wpdb->get_results("SELECT * FROM {$wpdb->base_prefix}pro_sites");

		return $sites;

	} // end get_all_pro_sites;

	/**
	 * Returns the probably owner of a site subscription.
	 *
	 * @since 0.0.1
	 * @param int $site_id The ID of the site to search.
	 * @return mixed.
	 */
	public function get_probable_site_owner($site_id) {

		/**
		 * Before looping though users, it might be a good idea to check if we see any users with
		 * the site email address.
		 */
		$site_email_address = get_blog_option($site_id, 'admin_email');

		$maybe_owner = get_user_by('email', $site_email_address);

		if ($maybe_owner && is_user_member_of_blog($maybe_owner->ID, $site_id)) {

			return $maybe_owner->ID;

		} // end if;

		/**
		 * Otherwise, let's basically guess, hehehe.
		 */
		$users = get_users_of_blog($site_id);

		if (empty($users)) {

			return false;

		} // end if;

		$probable_owner = array_shift($users);

		return (int) $probable_owner->ID;

	} // end get_probable_site_owner;

	/**
	 * Get all pro-sites and convert them to WP Ultimo Subscriptions
	 *
	 * @since 0.0.1
	 * @param array $sites List of Pro Sites.
	 * @return boolean
	 */
	public function convert_pro_sites_to_wp_ultimo_subscriptions($sites) {

		global $wpdb;

		$wpdb->query('START TRANSACTION');

		$added = array();

		$updated = array();

		$failed = array();

		WU_Logger::add('pro-sites-migrator', '  ');
		WU_Logger::add('pro-sites-migrator', 'Migrating Subscriptions:');

		foreach ($sites as $site) {

			try {

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Migrating Pro Site with ID %d...', $site->blog_ID)); // phpcs:ignore

				$status = $this->convert_pro_site_to_wp_ultimo_subscription($site);

				if ($status == 'added') {

					$added[] = $site;

					WU_Logger::add('pro-sites-migrator', sprintf('|---- New subscription successfully added. Moving on.', $site->blog_ID)); // phpcs:ignore

				} else {

					$updated[] = $site;

					WU_Logger::add('pro-sites-migrator', sprintf('|---- Subscription already existed. Updating it and moving on.', $site->blog_ID)); // phpcs:ignore

				} // end if;

			} catch (Exception $e) {

				/**
				 * Rollback transactions
				 */
				$wpdb->query('ROLLBACK');

				WU_Logger::add('pro-sites-migrator', sprintf("|---- Error migrating Pro Site %s: %s. Rolling back...", $site->blog_ID, $e->getMessage())); // phpcs:ignore

				return array(
					'success' => false,
					'added'   => array(),
					'updated' => array(),
					'failed'  => array(),
				);

			} // end try;

		} // end foreach;

		/**
		 * All good, commit.
		 */
		$wpdb->query('COMMIT');

		WU_Logger::add('pro-sites-migrator', 'No errors found while migrating the Subscriptions!');

		return array(
			'success' => true,
			'added'   => $added,
			'updated' => $updated,
			'failed'  => $failed,
		);

	} // end convert_pro_sites_to_wp_ultimo_subscriptions;

	/**
	 * Convert a site to a WU_Subscription objetc, if necessary.
	 *
	 * @since 0.0.1
	 * @param array $site Pro Site.
	 * @return string
	 */
	public function convert_pro_site_to_wp_ultimo_subscription($site) {

		$site_owner = $this->get_probable_site_owner($site->blog_ID); // phpcs:ignore

		if (!$site_owner) {

			WU_Logger::add('pro-sites-migrator', sprintf('|-- No user owner found for site ID %s. Skipping...', $site->blog_ID)); // phpcs:ignore

			return;

		} // end if;

		$new = false;

		/**
		 * Then, is time to add the site to that user.
		 */
		$wu_site = new WU_Site($site->blog_ID); // phpcs:ignore

		/**
		 * Check if this user already has a subscription
		 */
		$subscription = wu_get_subscription($site_owner);

		/**
		 * Try to get the plan for that subscription.
		 */
		$plan = $this->get_new_plan($site->level);

		/**
		 * Get Pro Site Meta
		 */
		$site_meta = maybe_unserialize($site->meta);

		/**
		 * Check if it's trial
		 */
		$is_trial = $site->gateway == 'trial' || (isset($site_meta['trialing']) && $site_meta['trialing']);

		/**
		 * Calculate trial days, if trial.
		 */
		$trial_days = floor(($site->expire - time()) / DAY_IN_SECONDS) - 1;

		/**
		 * Gateway options
		 */
		$gateway = $site->gateway !== 'trial' ? $site->gateway : null;

		/**
		 * If there isn't a subscription, we need to create one for that user.
		 */
		if (!$subscription) {

			$new = true;

			$data = array(
				'user_id'            => $site_owner,
				'trial'              => $is_trial ? $trial_days : 0,
				'created_at'         => $wu_site->site->registered, // date('Y-m-d H:i:s'),
				'last_plan_change'   => $wu_site->site->registered, // date('Y-m-d H:i:s'),
				'plan_id'            => $plan ? $plan->id : 0,
				'freq'               => (int) $site->term,
				'price'              => $plan ? WU_Util::to_float($plan->get_price($site->term)) : 0,
				'gateway'            => $gateway,
				'integration_status' => $gateway ? 1 : 0,
				'active_until'       => date('Y-m-d H:i:s', $site->expire),
				'paid_setup_fee'     => true,
			);

			$subscription = new WU_Subscription((object) $data);

		} else {

			/**
			 * Refreshes prices
			 */
			$combined_prices = $this->combine_prices(array(
				array(
					'freq'  => (int) $subscription->freq,
					'price' => $subscription->price,
				),
				array(
					'freq'  => (int) $site->term,
					'price' => $plan ? WU_Util::to_float($plan->get_price($site->term)) : 0,
				),
			));

			/**
			 * Set combined values
			 */
			$subscription->freq  = (int) $combined_prices['freq'];
			$subscription->price = WU_Util::to_float($combined_prices['price']);

		} // end if;

		/**
		 * Refresh Plan, if it is a greater plan
		 */
		if ($plan && $plan->id > $subscription->plan_id) {

			$subscription->plan_id = $plan ? $plan->id : 0;

		} // end if;

		/**
		 * Refresh Expire date
		 */
		if (strtotime($subscription->active_until) < $site->expire) {

			$subscription->active_until = date('Y-m-d H:i:s', $site->expire);

		} // end if;

		/**
		 * Save the site meta
		 */
		$prosites_count = $new ? 0 : (int) $subscription->get_meta('prosites_count');

		$subscription->set_meta('prosites_count', $prosites_count + 1);

		/**
		 * Save subscription
		 */
		$result = $subscription->save();

		if ($result) {

			$wu_site->set_owner($site_owner, 'administrator');

			/**
			 * Handle Stripe Subscriptions
			 */
			if ($gateway == 'stripe') {

				$this->handle_stripe_customers($site, $subscription, $plan);

			} // end if;

			/**
			 * Handle PayPal Subscriptions
			 */
			if ($gateway == 'paypal') {

				$this->handle_paypal_customers($site, $subscription, $plan);

			} // end if;

		} // end if;

		return $new ? 'added' : 'updated';

	} // end convert_pro_site_to_wp_ultimo_subscription;

	/**
	 * Combines the prices of a bunch of different ProSites into one consolidated billig.
	 *
	 * @since 0.0.1
	 * @param array $prices Keys are the billing frequency, value is the price being paid.
	 * @return array
	 */
	public function combine_prices($prices) {

		$base_freq = max(array_column($prices, 'freq'));

		$final_price = 0;

		foreach ($prices as $price) {

			$final_price += $base_freq / $price['freq'] * $price['price'];

		} // end foreach;

		return array(
			'freq'  => $base_freq,
			'price' => $final_price,
		);

	} // end combine_prices;

	/**
	 * Handles the Stripe Integration
	 *
	 * @since 0.0.1
	 * @throws Exception Throws exception if the Stripe gateway is not present.
	 * @param array           $site Pro Site array.
	 * @param WU_Subscription $subscription WP Ultimo subscription.
	 * @param WU_Plan         $plan The plan on WP Ultimo.
	 * @return void
	 */
	public function handle_stripe_customers($site, $subscription, $plan) {

		global $wpdb;

		$gateway = wu_get_gateway('stripe');

		if (!$gateway) {

			throw new Exception(__('Stripe Gateway not found.', 'wups-migrator'));

		} // end if;

		/**
		 * Get Pro Sites uiser info
		 */
		$stripe_info = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->base_prefix}pro_sites_stripe_customers WHERE blog_id = %s", $site->blog_ID));

		if ($subscription->integration_key != $stripe_info->customer_id || $subscription->meta->subscription_id !== $stripe_info->subscription_id) {

			/**
			 * Create the Integration on WP Ultimo
			 */
			$gateway->create_integration($subscription, $plan, (int) $site->term, $stripe_info->customer_id, array(
				'subscription_id' => $stripe_info->subscription_id,
			));

		} // end if;

		$stripe_customer = false;

		/**
		 * Update the customer on ProSites, so we can deal with webhooks later.
		 */
		try {

			$stripe_customer = WU_Stripe\Customer::retrieve($stripe_info->customer_id);

		} catch (Exception $e) {

			WU_Logger::add('pro-sites-migrator', sprintf("Stripe Migration Warning (this is expected on staging environment tests): %s", $e->getMessage()));

		} // end try;

		/**
		 * Saves the customer with the new meta on Stripe.
		 */
		if ($stripe_customer && $stripe_customer->metadata->user_id == null) {

			$stripe_customer->metadata->user_id = $subscription->user_id;

			$stripe_customer->save();

		} // end if;

	} // end handle_stripe_customers;

	/**
	 * Handles the PayPal Integration
	 *
	 * @since 0.0.1
	 * @throws Exception Throws exception if the Stripe gateway is not present.
	 * @param array           $site Pro Site array.
	 * @param WU_Subscription $subscription WP Ultimo subscription.
	 * @param WU_Plan         $plan The plan on WP Ultimo.
	 * @return void
	 */
	public function handle_paypal_customers($site, $subscription, $plan) {

		global $wpdb;

		$gateway = wu_get_gateway('paypal');

		if (!$gateway) {

			throw new Exception(__('PayPal Gateway not found.', 'wups-migrator'));

		} // end if;

		$site_id = $site->blog_ID; // phpcs:ignore

		$paypal_integration_data = array_keys(get_blog_option($site_id, 'psts_paypal_profile_id', array()));

		if (empty($paypal_integration_data)) {

			throw new Exception(__('No PayPal profile data found for this site.', 'wups-migrator'));

		} // end if;

		$profile_id = $paypal_integration_data[0];

		$gateway->create_integration($subscription, $plan, (int) $site->term, $profile_id, array(
			'identifier' => $site->identifier,
		));

		/**
		 * Saves cache for PayPal Transactions
		 */
		$paypal_transactions = array_keys(get_blog_option($site_id, 'psts_payments_log', array()));

		$this->add_paypal_transaction_cache($subscription->user_id, $paypal_transactions);

	} // end handle_paypal_customers;

	/**
	 * Retrieve the transaction cache from the database.
	 *
	 * Since pro-sites does not save info that allows us to directly link transactions and subscriptions,
	 * we need to create a id cache here, before moving one.
	 *
	 * @since 0.0.1
	 * @return array
	 */
	public function get_paypal_transaction_cache() {

		$cache = get_site_transient('wu_paypal_transaction_cache');

		return $cache ?: array();

	} // end get_paypal_transaction_cache;

	/**
	 * Adds a list of transactions to the cache, linking them to a given subscription id.
	 *
	 * @since 0.0.1
	 * @param int   $user_id ID of the user.
	 * @param array $transactions List of transactions.
	 * @return void
	 */
	public function add_paypal_transaction_cache($user_id, $transactions) {

		$cache = $this->get_paypal_transaction_cache();

		foreach ($transactions as $transaction_id) {

			$cache[$transaction_id] = $user_id;

		} // end foreach;

		set_site_transient('wu_paypal_transaction_cache', $cache, 10 * MINUTE_IN_SECONDS);

	} // end add_paypal_transaction_cache;

	/**
	 * Gets the plan based on the user level.
	 *
	 * @since 0.0.1
	 * @param int $level Pro Sites level.
	 * @return WU_Plan|null
	 */
	public function get_new_plan($level) {

		$levels = (array) get_site_option('psts_levels');

		if (isset($levels[$level])) {

			$plan_slug = sanitize_title($levels[$level]['name']);

			$wu_plan = wu_get_plan_by_slug($plan_slug);

			return $wu_plan ?: null;

		} // end if;

		return null;

	}  // end get_new_plan;

	/**
	 * Get all the transactions from Pro Sites.
	 *
	 * @since 0.0.1
	 * @return array
	 */
	public function get_pro_sites_transactions() {

		global $wpdb;

		$transactions = $wpdb->get_results("SELECT * FROM {$wpdb->base_prefix}pro_sites_transactions");

		return $transactions;

	} // end get_pro_sites_transactions;

	/**
	 * Checks if a transaction already exists.
	 *
	 * @since 0.0.1
	 * @param string $reference_id Transaction reference id.
	 * @return bool
	 */
	public function check_if_wp_ultimo_transaction_exists($reference_id) {

		global $wpdb;

		$query = $wpdb->prepare("SELECT * FROM {$wpdb->base_prefix}wu_transactions WHERE reference_id = %s", $reference_id);

		$transactions = $wpdb->get_results($query);

		return !empty($transactions);

	} // end check_if_wp_ultimo_transaction_exists;

	/**
	 * Takes a Pro Sites list transactions and converts them to WP Ultimo transactions.
	 *
	 * @since 0.0.1
	 * @param array $transactions List of transactions.
	 * @return array
	 */
	public function convert_transactions_to_wp_ultimo($transactions) {

		global $wpdb;

		$wpdb->query('START TRANSACTION');

		$added = array();

		$updated = array();

		$failed = array();

		WU_Logger::add('pro-sites-migrator', '  ');
		WU_Logger::add('pro-sites-migrator', 'Migrating Transactions:');

		foreach ($transactions as $transaction) {

			$lines = maybe_unserialize($transaction->items);

			/**
			 * Already have this transaction in the database?
			 */
			if ($this->check_if_wp_ultimo_transaction_exists($transaction->transaction_id)) {

				$updated[] = $transaction;

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Transaction %s already existed, skipping it.', $transaction->id));

				continue;

			} // end if;

			/**
			 * Create the description
			 */
			$desc = array();

			/**
			 * Search for the target subscription
			 */
			$target_sub = '';

			/**
			 * Gateway
			 */
			$gateway = '';

			foreach ($lines as $line) {

				$desc[] = $line->description;

				/**
				 * Stripe Transaction
				 */
				if (strpos($line->custom_id, 'sub_') === 0) {

					$target_sub = $line->custom_id;

					$gateway = 'stripe';

				} else {

					$target_sub = $transaction->transaction_id;

					$gateway = 'paypal';

				} // end if;

			} // end foreach;

			/**
			 * Get target subscription
			 */
			if (!$target_sub || !$gateway) {

				$failed[] = $transaction;

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Transaction %s has no associated subscription or has an invalid gateway, skipping it.', $transaction->id));

				continue;

			} // end if;

			/**
			 * Get the user ID for a given subscription.
			 */
			$user_id = $this->get_user_id_by_transaction_reference($target_sub, $gateway);

			if (!$user_id) {

				$failed[] = $transaction;

				continue;

			} // end if;

			/**
			 * Build new transaction
			 */
			$new_transaction = array(
				'user_id'         => $user_id,
				'reference_id'    => $transaction->transaction_id,
				'type'            => 'payment',
				'nature'          => 'normal',
				'amount'          => WU_Util::to_float($transaction->total),
				'original_amount' => WU_Util::to_float($transaction->total),
				'gateway'         => $gateway,
				'description'     => implode(' + ', $desc),
				'time'            => $transaction->transaction_date . ' 12:00:00',
			);

			$table_name = WU_Transactions::get_table_name();

			$result = $wpdb->insert($table_name, $new_transaction);

			if ($result) {

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Transaction %s successfully added. Moving on.', $transaction->id));

				$added[] = $transaction;

			} else {

				$wpdb->query('ROLLBACK');

				WU_Logger::add('pro-sites-migrator', sprintf('|-- There was an error moving transaction %d. Rolling back...', $transaction->id));

				return array(
					'success' => false,
					'added'   => $added,
					'updated' => $updated,
					'failed'  => $transactions,
				);

			} // end if;

		} // end foreach;

		$wpdb->query('COMMIT');

		WU_Logger::add('pro-sites-migrator', 'No errors migrating transactions. Commiting changes to the database...');

		return array(
			'success' => true,
			'added'   => $added,
			'updated' => $updated,
			'failed'  => $failed,
		);

	} // end convert_transactions_to_wp_ultimo;

	/**
	 * Get user id based on the transaction reference.
	 *
	 * @since 0.0.1
	 * @param string $reference Reference to search.
	 * @param string $gateway   Gateway to check.
	 * @return int|false
	 */
	public function get_user_id_by_transaction_reference($reference, $gateway = '') {

		global $wpdb;

		$user_id = wp_cache_get("{$reference}-{$gateway}", 'wu_user_id_transaction');

		if (!$user_id) {

			if ($gateway == 'stripe') {

				/**
				 * Get the user ID for a given subscription
				 */
				$query = $wpdb->prepare("SELECT user_id from {$wpdb->base_prefix}wu_subscriptions WHERE meta_object LIKE %s", '%' . $reference . '%');

				$user_id = $wpdb->get_var($query);

			} // end if;

			if ($gateway == 'paypal') {

				$paypal_transaction_cache = $this->get_paypal_transaction_cache();

				if (isset($paypal_transaction_cache[$reference])) {

					$user_id = $paypal_transaction_cache[$reference];

				} // end if;

			} // end if;

			if ($user_id) {

				/**
				 * Set the cache, if we found something.
				 */
				wp_cache_add("{$reference}-{$gateway}", $user_id, 'wu_user_id_transaction', 1 * MINUTE_IN_SECONDS);

			} // end if;

		} // end if;

		return $user_id;

	} // end get_user_id_by_transaction_reference;

} // end class WU_PS_Subscription_Migrator;

/**
 * Returns the singleton
 */
function WU_PS_Subscription_Migrator() { // phpcs:ignore

	return WU_PS_Subscription_Migrator::get_instance();

} // end WU_PS_Subscription_Migrator;

// Initialize
WU_PS_Subscription_Migrator();

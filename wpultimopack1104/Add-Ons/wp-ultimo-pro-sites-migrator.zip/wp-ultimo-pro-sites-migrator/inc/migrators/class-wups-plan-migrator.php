<?php
/**
 * Plan Migrator
 *
 * Takes Pro Sites plans and transfers them to WP Ultimo.
 *
 * @since       0.0.1
 * @author      Arindo Duque
 * @category    Migrator
 * @package     WP_Ultimo_PS_Migrator/Migrators/Plan
 * @version     0.0.1
 */

if (!defined('ABSPATH')) {
	exit;
} // end if;

/**
 * Migrates the Plan from Pro Sites to WP Ultimo
 *
 * @since 0.0.1
 */
class WU_PS_Plan_Migrator {

	/**
	 * Makes sure we are only using one instance of the class
	 *
	 * @since 1.8.2
	 * @var WU_PS_Plan_Migrator
	 */
	public static $instance;

	/**
	 * Keeps a copy of the plugin version for caching purposes
	 *
	 * @since 1.8.2
	 * @var string
	 */
	public $version = '1.0.0';

	/**
	 * Returns the instance of WP_Ultimo
	 *
	 * @return object A WU_PS_Plan_Migrator instance
	 */
	public static function get_instance() {

		if (null === self::$instance) {

			self::$instance = new self();

		} // end if;

		return self::$instance;

	} // end get_instance;

	/**
	 * Initializes the class
	 */
	public function __construct() {}  // end __construct;

	/**
	 * Gets all the plans on Pro SitesÍ
	 *
	 * @since 0.0.1
	 * @return array
	 */
	public function get_ps_plans() {

		$plans = get_site_option('psts_levels');

		return $plans;

	} // end get_ps_plans;

	/**
	 * Checks which plugins we need to make available to our new plans.
	 *
	 * @since 0.0.1
	 * @param array $plans List of Pro Sites plans.
	 * @return array
	 */
	public function populate_plan_allowed_plugins($plans) {

		global $psts;

		/**
		 * Available Plugins
		 */
		$psts_plugins = (array) $psts->get_setting('pp_plugins');

		foreach ($psts_plugins as $plugin => $plugin_settings) {

			for ($i = 1; $i <= count($plans); $i++) {

				if ($plugin_settings['level'] <= $i) {

					$allowed_plugins = isset($plans[$i]['allowed_plugins']) ? $plans[$i]['allowed_plugins'] : array();

					/**
					 * Add the plugin to the allowed list.
					 */
					$allowed_plugins[$plugin] = true;

					$plans[$i]['allowed_plugins'] = $allowed_plugins;

				} // end if;

			} // end for;

		} // end foreach;

		return $plans;

	} // end populate_plan_allowed_plugins;

	/**
	 * Checks which themes we need to make available to our new plans.
	 *
	 * @since 0.0.1
	 * @param array $plans List of Pro Sites plans.
	 * @return array
	 */
	public function populate_plan_allowed_themes($plans) {

		global $psts;

		/**
		 * Available Themes
		 */
		$psts_themes = (array) $psts->get_setting('pt_allowed_themes');

		foreach ($psts_themes as $theme => $theme_min_level) {

			if ($theme_min_level == 0) {

				continue;

			} // end if;

			for ($i = 1; $i <= count($plans); $i++) {

				if ($theme_min_level <= $i) {

					$allowed_themes = isset($plans[$i]['allowed_themes']) ? $plans[$i]['allowed_themes'] : array();

					/**
					 * Add the plugin to the allowed list.
					 */
					$allowed_themes[$theme] = true;

					$plans[$i]['allowed_themes'] = $allowed_themes;

				} // end if;

			} // end for;

		} // end foreach;

		return $plans;

	} // end populate_plan_allowed_themes;

	/**
	 * Convert a list of PS Plans to WP Ultimo Plans
	 *
	 * @since 0.0.1
	 * @param array $plans List of plans.
	 * @return array
	 */
	public function convert_to_wu_plans($plans) {

		global $psts, $wpdb;

		$wpdb->query('START TRANSACTION');

		$added = array();

		$updated = array();

		$failed = array();

		WU_Logger::add('pro-sites-migrator', '  ');
		WU_Logger::add('pro-sites-migrator', 'Migrating Plans:');

		/**
		 * Before actualy converting, we need to populate the allowed plugins...
		 */
		$plans = $this->populate_plan_allowed_plugins($plans);

		/**
		 * ...and the allowed themes
		 */
		$plans = $this->populate_plan_allowed_themes($plans);

		/**
		 * Convert the plans
		 */
		foreach ($plans as $ps_plan_id => $ps_plan) {

			$plan_slug = sanitize_title($ps_plan['name']);

			/**
			 * Check if plan exists
			 */
			$wu_plan = wu_get_plan_by_slug($plan_slug);

			$wu_plan = $wu_plan ?: new WU_Plan(0);

			/**
			 * Set the options
			 */
			$wu_plan->title           = $ps_plan['name'];
			$wu_plan->description     = '';
			$wu_plan->price_1         = WU_Util::to_float($ps_plan['price_1']);
			$wu_plan->price_3         = WU_Util::to_float($ps_plan['price_3']);
			$wu_plan->price_12        = WU_Util::to_float($ps_plan['price_12']);
			$wu_plan->setup_fee       = WU_Util::to_float($psts->get_setting('setup_fee', 0));
			$wu_plan->hidden          = $ps_plan['is_visible'] == false;
			$wu_plan->allowed_plugins = array_keys($ps_plan['allowed_plugins']);
			$wu_plan->allowed_themes  = array_keys($ps_plan['allowed_themes']);
			$wu_plan->order           = $ps_plan_id;

			/**
			 * Quotas
			 */
			$wu_plan->quotas = array(
				'upload' => $psts->get_level_setting($ps_plan_id, 'quota'),
			);

			/**
			 * Supports domain mapping?
			 */
			$wu_plan->custom_domain = $this->check_if_level_supports_domain_mapping($ps_plan_id);

			/**
			 * Is a new plan
			 */
			$new = $wu_plan->id == 0;

			/**
			 * Save
			 */
			$saved = $wu_plan->save();

			if (!$saved) {

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Error migrating plan %s. This will rollback the entire plan migration later...', $ps_plan['name']));

				$failed[$plan_slug] = $ps_plan;

			} // end if;

			if ($saved && $new) {

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Successfully migrated Plan %s. Moving on.', $ps_plan['name']));

				$added[$plan_slug] = $ps_plan;

			} // end if;

			if ($saved && !$new) {

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Plan %s already existed, updating it. Moving on.', $ps_plan['name']));

				$updated[$plan_slug] = $ps_plan;

			} // end if;

		} // end foreach;

		$success = count($failed) == 0;

		/**
		 * Commit or Rollback
		 */
		$success ? $wpdb->query('COMMIT') : $wpdb->query('ROLLBACK');

		if ($success) {

			WU_Logger::add('pro-sites-migrator', 'No errors migrating plans. Commiting changes to the database...');

		} else {

			WU_Logger::add('pro-sites-migrator', sprintf('There were %d errors during plan migration... Rolling back...', count($failed)));

		} // end if;

		return array(
			'success' => $success,
			'added'   => $added,
			'updated' => $updated,
			'failed'  => $failed,
		);

	} // end convert_to_wu_plans;

	/**
	 * Check if a given level supports domain mapping.
	 *
	 * @since 0.0.1
	 * @param int $level Pro Sites level.
	 * @return bool
	 */
	public function check_if_level_supports_domain_mapping($level) {

		$settings = get_network_option(null, 'domain_mapping', array());

		if (!isset($settings['map_supporteronly'])) {

			return false;

		} // end if;

		return in_array($level, $settings['map_supporteronly']);

	} // end check_if_level_supports_domain_mapping;

} // end class WU_PS_Plan_Migrator;

/**
 * Returns the singleton
 */
function WU_PS_Plan_Migrator() { // phpcs:ignore

	return WU_PS_Plan_Migrator::get_instance();

} // end WU_PS_Plan_Migrator;

// Initialize
WU_PS_Plan_Migrator();

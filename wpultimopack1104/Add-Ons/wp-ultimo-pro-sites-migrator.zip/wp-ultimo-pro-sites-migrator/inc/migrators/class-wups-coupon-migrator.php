<?php
/**
 * Coupon Migrator
 *
 * Takes Pro Sites coupons and transfers them to WP Ultimo.
 *
 * @since       0.0.1
 * @author      Arindo Duque
 * @category    Migrator
 * @package     WP_Ultimo_PS_Migrator/Migrators/Coupon
 * @version     0.0.1
 */

if (!defined('ABSPATH')) {
	exit;
} // end if;

/**
 * Migrates the Coupons from Pro Sites to WP Ultimo
 *
 * @since 0.0.1
 */
class WU_PS_Coupon_Migrator {

	/**
	 * Makes sure we are only using one instance of the class
	 *
	 * @since 1.8.2
	 * @var WU_PS_Coupon_Migrator
	 */
	public static $instance;

	/**
	 * Keeps a copy of the plugin version for caching purposes
	 *
	 * @since 1.8.2
	 * @var string
	 */
	public $version = '1.0.0';

	/**
	 * Returns the instance of WP_Ultimo
	 *
	 * @return object A WU_PS_Coupon_Migrator instance
	 */
	public static function get_instance() {

		if (null === self::$instance) {

			self::$instance = new self();

		} // end if;

		return self::$instance;

	} // end get_instance;

	/**
	 * Initializes the class
	 */
	public function __construct() {

	}  // end __construct;

	/**
	 * Gets all the coupons on Pro SitesÍ
	 *
	 * @since 0.0.1
	 * @return array
	 */
	public function get_ps_coupons() {

		$coupons = get_site_option('psts_coupons');

		return $coupons;

	} // end get_ps_coupons;

	/**
	 * Convert a list of PS Coupons to WP Ultimo Coupons
	 *
	 * @since 0.0.1
	 * @param array $coupons List of coupons.
	 * @return array
	 */
	public function convert_to_wu_coupons($coupons) {

		global $wpdb;

		$wpdb->query('START TRANSACTION');

		$added = array();

		$updated = array();

		$failed = array();

		WU_Logger::add('pro-sites-migrator', '  ');
		WU_Logger::add('pro-sites-migrator', 'Migrating Coupons:');

		foreach ($coupons as $ps_coupon_code => $ps_coupon) {

			/**
			 * Check if coupon exists
			 */
			$wu_coupon = wu_get_coupon($ps_coupon_code);

			$wu_coupon = $wu_coupon ?: new WU_Coupon(0);

			/**
			 * Set the options
			 */
			$wu_coupon->title         = $ps_coupon_code;
			$wu_coupon->description   = sprintf(__('Imported from Pro Sites', 'wu-ps-migrator'), $ps_coupon_code);
			$wu_coupon->allowed_uses  = (int) $ps_coupon['uses'];
			$wu_coupon->type          = $ps_coupon['discount_type'] == 'amt' ? 'absolute' : 'percent';
			$wu_coupon->cycles        = $ps_coupon['lifetime'] == 'indefinite' ? 0 : 1;
			$wu_coupon->value         = WU_Util::to_float($ps_coupon['discount']);
			$wu_coupon->allowed_plans = array();
			$wu_coupon->allowed_freqs = $ps_coupon['valid_for_period'];
			$wu_coupon->expiring_date = $ps_coupon['end'] ? date('Y-m-d H:i:s', $ps_coupon['end']) : '';

			/**
			 * Is a new coupon
			 */
			$new = $wu_coupon->id == 0;

			/**
			 * Save
			 */
			$saved = $wu_coupon->save();

			if (!$saved) {

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Error migrating coupon %s. This will rollback the entire coupon migration later...', $ps_coupon_code));

				$failed[$ps_coupon_code] = $ps_coupon;

			} // end if;

			if ($saved && $new) {

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Successfully migrated Coupon %s. Moving on.', $ps_coupon_code));

				$added[$ps_coupon_code] = $ps_coupon;

			} // end if;

			if ($saved && !$new) {

				WU_Logger::add('pro-sites-migrator', sprintf('|-- Coupon %s already existed, updating it. Moving on.', $ps_coupon_code));

				$updated[$ps_coupon_code] = $ps_coupon;

			} // end if;

		} // end foreach;

		$success = count($failed) == 0;

		/**
		 * Commit or Rollback
		 */
		$success ? $wpdb->query('COMMIT') : $wpdb->query('ROLLBACK');

		if ($success) {

			WU_Logger::add('pro-sites-migrator', 'No errors migrating coupon codes. Commiting changes to the database...');

		} else {

			WU_Logger::add('pro-sites-migrator', sprintf('There were %d errors during coupon migration... Rolling back...', count($failed)));

		} // end if;

		return array(
			'success' => $success,
			'added'   => $added,
			'updated' => $updated,
			'failed'  => $failed,
		);

	} // end convert_to_wu_coupons;

} // end class WU_PS_Coupon_Migrator;

/**
 * Returns the singleton
 */
function WU_PS_Coupon_Migrator() { // phpcs:ignore

	return WU_PS_Coupon_Migrator::get_instance();

} // end WU_PS_Coupon_Migrator;

// Initialize
WU_PS_Coupon_Migrator();

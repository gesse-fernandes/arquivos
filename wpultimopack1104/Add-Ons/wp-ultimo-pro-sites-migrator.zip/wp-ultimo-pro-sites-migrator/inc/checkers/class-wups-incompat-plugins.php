<?php
/**
 * Disable Incompatible Plugins
 *
 * Searches for incompatible WPMUDev Plugins and disable them
 *
 * @since       0.0.1
 * @author      Arindo Duque
 * @category    Migrator
 * @package     WP_Ultimo_PS_Migrator/Checkers/Plugins
 * @version     0.0.1
 */

if (!defined('ABSPATH')) {
	exit;
} // end if;

/**
 * Searches for incompatible WPMUDev Plugins and disable them
 *
 * @since 0.0.1
 */
class WU_PS_Incompat_Plugins {

	/**
	 * Makes sure we are only using one instance of the class
	 *
	 * @since 1.8.2
	 * @var WU_PS_Incompat_Plugins
	 */
	public static $instance;

	/**
	 * Keeps a copy of the plugin version for caching purposes
	 *
	 * @since 1.8.2
	 * @var string
	 */
	public $version = '1.0.0';

	/**
	 * Returns the instance of WP_Ultimo
	 *
	 * @return object A WU_PS_Incompat_Plugins instance
	 */
	public static function get_instance() {

		if (null === self::$instance) {

			self::$instance = new self();

		} // end if;

		return self::$instance;

	} // end get_instance;

	/**
	 * Initializes the class
	 */
	public function __construct() { } // end __construct;

	/**
	 * Get list of the plugins that cause problems with WP Ultimo
	 *
	 * @since 0.0.1
	 * @return array
	 */
	public function get_incompat_plugins() {

		return array(
			'pro-sites/pro-sites.php'             => array(
				'name'   => __('Pro Sites', 'wu-ps-migrator'),
				'desc'   => __('The entire point of this migrator is to deactivate Pro Sites, right? You can keep it active if you prefer to see if migrated data match, but before testing your network, be sure to deactivate it.', 'wu-ps-migrator'),
				'active' => function_exists('signup_language_setup'),
			),
			'domain-mapping/domain-mapping.php'   => array(
				'name'   => __('Domain Mapping', 'wu-ps-migrator'),
				'desc'   => __('You chose to migrate to WP Ultimo\'s Domain Mapping. Keeping this active will cause trouble.', 'wu-ps-migrator'),
				'active' => function_exists('signup_language_setup'),
			),
			'signup-language/signup-language.php' => array(
				'name'   => __('Signup Language', 'wu-ps-migrator'),
				'desc'   => __('This causes the WP Ultimo sign-up to halt on the last step. WP Ultimo has an add-on that offers the same functionality, called WP Ultimo: Language Switcher.', 'wu-ps-migrator'),
				'active' => function_exists('signup_language_setup'),
			),
			'signup-blog-description/signup-blog-description.php' => array(
				'name'   => __('Set Blog Description on Blog Creation', 'wu-ps-migrator'),
				'desc'   => __('This causes the WP Ultimo sign-up to halt on the last step.', 'wu-ps-migrator'),
				'active' => class_exists('SignupBlogDescription'),
			),
			'blogtemplates/blogtemplates.php' => array(
				'name'   => __('New Blog Templates', 'wu-ps-migrator'),
				'desc'   => __('WP Ultimo has an equivalent feature and your blog templates were already migrated.', 'wu-ps-migrator'),
				'active' => class_exists('SignupBlogDescription'),
			),
			'signup-password/signup-password.php' => array(
				'name'   => __('Set Password on Multisite Blog Creation', 'wu-ps-migrator'),
				'desc'   => __('This causes the WP Ultimo sign-up to halt on the last step.', 'wu-ps-migrator'),
				'active' => function_exists('wpmu_signup_password_init'),
			),
			'anti-splog/anti-splog.php'           => array(
				'name'   => __('Anti-Splog', 'wu-ps-migrator'),
				'desc'   => __('This causes the WP Ultimo sign-up to halt on the last step. WP Ultimo uses a simple honeypot strategy to prevent spam signups and it is pretty effective.', 'wu-ps-migrator'),
				'active' => function_exists('ust_wpsignup_init'),
			),
			'signup-tos/signup-tos.php'           => array(
				'name'   => __('Signup TOS', 'wu-ps-migrator'),
				'desc'   => __('This causes the WP Ultimo sign-up to halt on the last step. WP Ultimo has this built-in our core plugin.', 'wu-ps-migrator'),
				'active' => function_exists('signup_tos_plug_pages'),
			),
		);

	} // end get_incompat_plugins;

	/**
	 * Returns te list of incompatible plugins that are actually installed and active
	 *
	 * @since 0.0.1
	 * @return array
	 */
	public function get_installed_incompat_plugins() {

		$plugins = $this->get_incompat_plugins();

		if (!function_exists('is_plugin_active_for_network')) {

			require_once(ABSPATH . '/wp-admin/includes/plugin.php');

		} // end if;

		$plugins = array_filter($plugins, function($key) {

			return is_plugin_active_for_network($key);

		}, ARRAY_FILTER_USE_KEY);

		return $plugins;

	} // end get_installed_incompat_plugins;

	/**
	 * Deactivate thhe plugins
	 *
	 * @since 0.0.1
	 * @param array $plugins List of plugins to deactivate.
	 * @return array
	 */
	public function deactivate_plugins($plugins) {

		deactivate_plugins($plugins, false, true);

		WU_Logger::add('pro-sites-migrator', sprintf('Deactivated %s. Moving on.', implode(', ', $plugins)));

		/**
		 * Domain Mapping exception.
		 */
		if (in_array('domain-mapping/domain-mapping.php', $plugins)) {

			/**
			 * Copy Sunrise
			 */
			wp_remote_get(admin_url('admin-ajax.php?action=wu_upgrade_sunrise'));

		} // end if;

		return array(
			'deactivated' => count($plugins),
		);

	} // end deactivate_plugins;

} // end class WU_PS_Incompat_Plugins;

/**
 * Returns the singleton
 */
function WU_PS_Incompat_Plugins() { // phpcs:ignore

	return WU_PS_Incompat_Plugins::get_instance();

} // end WU_PS_Incompat_Plugins;

// Initialize
WU_PS_Incompat_Plugins();

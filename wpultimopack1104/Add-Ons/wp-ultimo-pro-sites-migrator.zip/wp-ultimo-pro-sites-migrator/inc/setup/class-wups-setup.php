<?php
/**
 * WP Ultimo Setup Wizards Class
 *
 * Based on the amazing work of dtbaker
 *
 * @author      Arindo Duque
 * @category    Setup
 * @package     WP_Ultimo/Setup
 * @version     0.0.1
*/

if (!defined( 'ABSPATH')) {
  exit;
}

if (!class_exists('WP_Ultimo_Pro_Sites_Migrator')) {
  
  /**
   * WP_Ultimo_Pro_Sites_Migrator class
   */
  class WP_Ultimo_Pro_Sites_Migrator {

    /**
     * The class version number.
     *
     * @since 1.1.1
     * @access private
     *
     * @var string
     */
    protected $version = '1.1.4';

    /** @var string Current theme name, used as namespace in actions. */
    protected $theme_name = '';

    /** @var string Theme author username, used in check for oauth. */
    protected $envato_username = '';

    /** @var string Full url to server-script.php (available from https://gist.github.com/dtbaker ) */
    protected $oauth_script = '';

    /** @var string Current Step */
    protected $step   = '';

    /** @var array Steps for the setup wizard */
    protected $steps  = array();

    /**
     * Relative plugin path
     *
     * @since 1.1.2
     *
     * @var string
     */
    protected $plugin_path = '';

    /**
     * Relative plugin url for this plugin folder, used when enquing scripts
     *
     * @since 1.1.2
     *
     * @var string
     */
    protected $plugin_url = '';

    /**
     * The slug name to refer to this menu
     *
     * @since 1.1.1
     *
     * @var string
     */
    protected $page_slug;

    /**
     * TGMPA instance storage
     *
     * @var object
     */
    protected $tgmpa_instance;

    /**
     * TGMPA Menu slug
     *
     * @var string
     */
    protected $tgmpa_menu_slug = 'tgmpa-install-plugins';

    /**
     * TGMPA Menu url
     *
     * @var string
     */
    protected $tgmpa_url = 'themes.php?page=tgmpa-install-plugins';

    /**
     * The slug name for the parent menu
     *
     * @since 1.1.2
     *
     * @var string
     */
    protected $page_parent;

    /**
     * Complete URL to Setup Wizard
     *
     * @since 1.1.2
     *
     * @var string
     */
    protected $page_url;


    /**
     * Holds the current instance of the theme manager
     *
     * @since 1.1.3
     * @var WP_Ultimo_Pro_Sites_Migrator
     */
    private static $instance = null;

    /**
     * @since 1.1.3
     *
     * @return WP_Ultimo_Pro_Sites_Migrator
     */
    public static function get_instance() {
      if ( ! self::$instance ) {
        self::$instance = new self;
      }

      return self::$instance;
    }

    /**
     * A dummy constructor to prevent this class from being loaded more than once.
     *
     * @see WP_Ultimo_Pro_Sites_Migrator::instance()
     *
     * @since 1.1.1
     * @access private
     */
    public function __construct() {
      $this->init_globals();
      $this->init_actions();
    }

    /**
     * Setup the class globals.
     *
     * @since 1.1.1
     * @access private
     */
    public function init_globals() {

      add_action('admin_init', function() {

        // $this->_migrate_domain_mappings();

        // die;

      });

      $this->page_slug = apply_filters('wu_setup_slug', 'wups-migrator');

      $this->parent_slug = apply_filters( $this->theme_name . '_theme_setup_wizard_parent_slug', '' );

      //If we have parent slug - set correct url
      $this->page_url = 'admin.php?page='.$this->page_slug;

      $this->page_url = apply_filters('wu_setup_page_url', $this->page_url);

      //set relative plugin path url
      $this->plugin_path = trailingslashit( $this->cleanFilePath( dirname( __FILE__ ) ) );

      $relative_url = WP_Ultimo_PS_Migrator()->url('/inc/setup/');
      $this->plugin_url = trailingslashit($relative_url);
    }

    /**
     * Setup the hooks, actions and filters.
     *
     * @uses add_action() To add actions.
     * @uses add_filter() To add filters.
     *
     * @since 1.1.1
     * @access private
     */
    public function init_actions() {


      if (current_user_can('manage_network')) {

        //register_activation_hook(WP_Ultimo()->path("wp-ultimo.php"), array($this, 'activate_plugin'));

        add_action('activate_wp-ultimo/wp-ultimo.php', array($this, 'activate_plugin'));

        // add_action('admin_init', array($this, 'switch_theme'));

        //              if (class_exists( 'TGM_Plugin_Activation' ) && isset($GLOBALS['tgmpa'])) {
        //                add_action( 'init', array( $this, 'get_tgmpa_instanse' ), 30 );
        //                add_action( 'init', array( $this, 'set_tgmpa_url' ), 40 );
        //              }

        add_action( 'network_admin_menu', array( $this, 'admin_menus' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'admin_init', array( $this, 'admin_redirects' ), 30 );
        add_action( 'admin_init', array( $this, 'init_wizard_steps' ), 30 );
        add_action( 'admin_init', array( $this, 'setup_wizard' ), 30 );
        add_filter( 'tgmpa_load', array( $this, 'tgmpa_load' ), 10, 1 );
        add_action( 'wp_ajax_wu_setup_plugins', array( $this, 'ajax_plugins' ) );
        add_action( 'wp_ajax_wu_setup_content', array( $this, 'ajax_content' ) );
        add_action( 'wp_ajax_wu_deactivate_plugins', array( $this, 'ajax_deactivate_plugins' ) );
      }

      //          if (function_exists( 'envato_market' ) ) {
      //            add_action( 'admin_init', array( $this, 'envato_market_admin_init' ), 20 );
      //            add_filter( 'http_request_args', array( $this, 'envato_market_http_request_args' ), 10, 2 );
      //          }
    }

    public function enqueue_scripts() {
    }
    
    public function tgmpa_load( $status ) {
      return is_admin() || current_user_can( 'install_themes' );
    }

    public function activate_plugin() {
      if (get_network_option(null, '_wpultimo_ps_migrator_activation_redirect') !== 'done')
        update_network_option(null,  '_wpultimo_ps_migrator_activation_redirect', false);
    }

    public function admin_redirects() {
      ob_start();
      if (isset($_GET['page']) && $_GET['page'] == $this->page_slug) return;
      // TODO: Descomment the check below
      if (get_network_option(null, '_wpultimo_ps_migrator_activation_redirect') == 'done') return;
      wp_safe_redirect(network_admin_url($this->page_url));
      update_network_option(null, '_wpultimo_ps_migrator_activation_redirect', 'done');
      exit;
    }

    /**
     * Get configured TGMPA instance
     *
     * @access public
     * @since 1.1.2
     */
    public function get_tgmpa_instanse(){
      $this->tgmpa_instance = call_user_func( array( get_class( $GLOBALS['tgmpa'] ), 'get_instance' ) );
    }

    /**
     * Update $tgmpa_menu_slug and $tgmpa_parent_slug from TGMPA instance
     *
     * @access public
     * @since 1.1.2
     */
    public function set_tgmpa_url(){

      $this->tgmpa_menu_slug = ( property_exists($this->tgmpa_instance, 'menu') ) ? $this->tgmpa_instance->menu : $this->tgmpa_menu_slug;
      $this->tgmpa_menu_slug = apply_filters($this->theme_name . '_theme_setup_wizard_tgmpa_menu_slug', $this->tgmpa_menu_slug);

      $tgmpa_parent_slug = ( property_exists($this->tgmpa_instance, 'parent_slug') && $this->tgmpa_instance->parent_slug !== 'themes.php' ) ? 'admin.php' : 'themes.php';

      $this->tgmpa_url = apply_filters($this->theme_name . '_theme_setup_wizard_tgmpa_url', $tgmpa_parent_slug.'?page='.$this->tgmpa_menu_slug);

    }

    /**
     * Add admin menus/screens.
     */
    public function admin_menus() {
      // Add submenu
      add_submenu_page('wups-migrator', __('Pro Sites Migrator', 'wp-ultimo'), __( 'Pro Sites Migrator','wp-ultimo'), 'manage_network', $this->page_slug, array($this, 'setup_wizard'));
    }

    /**
     * Setup steps.
     *
     * @since 1.1.1
     * @access public
     * @return array
     */
    public function init_wizard_steps() {

      $this->steps = array(
        'introduction' => array(
          'name'    => __( 'Introduction', 'wp-ultimo'),
          'view'    => array($this, 'wu_setup_introduction' ),
          'handler' => '',
        ),
      );

      $this->steps['info-and-risks'] = array(
        'name'    => __('Info & Risks', 'wp-ultimo'),
        'view'    => array($this, 'wu_setup_risks'),
        'handler' => '',
      );

      $this->steps['options'] = array(
        'name'    => __('Options', 'wp-ultimo'),
        'view'    => array($this, 'wu_setup_options'),
        'handler' => array($this, 'wu_setup_options_save'),
      );


    
      // $this->steps['settings'] = array(
      //   'name'    => __('Settings', 'wp-ultimo'),
      //   'view'    => array($this, 'wu_setup_settings'),
      //   'handler' => array($this, 'wu_setup_settings_save'),
      // );

      // $this->steps['checks'] = array(
      //   'name'    => __('System', 'wp-ultimo'),
      //   'view'    => array($this, 'wu_setup_checks'),
      //   'handler' => array($this, 'wu_setup_checks_save'),
      // );

      $this->steps['migrating'] = array(
        'name'    => __('Migration', 'wp-ultimo'),
        'view'    => array($this, 'wu_setup_migrating_content'),
        'handler' => '',
      );

      $this->steps['plugins'] = array(
        'name'    => __('Plugins', 'wp-ultimo'),
        'view'    => array($this, 'wu_setup_deactivating_plugins'),
        'handler' => '',
      );

      // $this->steps['design'] = array(
      //   'name'    => __('Logo', 'wp-ultimo'),
      //   'view'    => array($this, 'wu_setup_logo_design' ),
      //   'handler' => array($this, 'wu_setup_logo_design_save'),
      // );

      $this->steps['next_steps'] = array(
        'name'    => __( 'Done!', 'wp-ultimo'),
        'view'    => array($this, 'wu_setup_ready'),
        'handler' => '',
      );

      return apply_filters(  $this->theme_name . '_theme_setup_wizard_steps', $this->steps );

    }

    /**
		 * Show the setup wizard
		 */
    public function setup_wizard() {
      if ( empty( $_GET['page'] ) || $this->page_slug !== $_GET['page'] ) {
        return;
      }
      ob_end_clean();

      set_current_screen('wu-setup');

      $this->step = isset( $_GET['step'] ) ? sanitize_key( $_GET['step'] ) : current( array_keys( $this->steps ) );

      wp_register_script( 'wu-setup', $this->plugin_url . '/js/wpultimo-setup.js', array( 'jquery', 'jquery-blockui' ), $this->version );
      wp_localize_script( 'wu-setup', 'wu_setup_params', array(
        'tgm_plugin_nonce'            => array(
          'update' => wp_create_nonce( 'tgmpa-update' ),
          'install' => wp_create_nonce( 'tgmpa-install' ),
        ),
        'tgm_bulk_url' => admin_url( $this->tgmpa_url ),
        'ajaxurl' => admin_url( 'admin-ajax.php' ),
        'wpnonce' => wp_create_nonce( 'wu_setup_nonce' ),
        'verify_text' => __( '...verifying','wp-ultimo'),
      ) );

      //wp_enqueue_style( 'envato_wizard_admin_styles', $this->plugin_url . '/css/admin.css', array(), $this->version );
      wp_enqueue_style( 'wups-migrator', $this->plugin_url . '/css/wpultimo-setup.css', array( 'dashicons', 'install' ), $this->version );

      //enqueue style for admin notices
      wp_enqueue_style( 'wp-admin' );

      wp_enqueue_media();
      wp_enqueue_script( 'media' );
      wp_enqueue_script( 'wu-setup' );
      wp_enqueue_script( 'wp-ultimo' );

      ob_start();
      $this->setup_wizard_header();
      $this->setup_wizard_steps();
      $show_content = true;
      echo '<div class="wpultimo-setup-content">';
      if ( ! empty( $_REQUEST['save_step'] ) && isset( $this->steps[ $this->step ]['handler'] ) ) {
        $show_content = call_user_func( $this->steps[ $this->step ]['handler'] );
      }
      if ( $show_content ) {
        $this->setup_wizard_content();
      }
      echo '</div>';
      $this->setup_wizard_footer();
      exit;
    }

    public function get_step_link( $step ) {
      return  add_query_arg( 'step', $step, admin_url( 'admin.php?page=' .$this->page_slug ) );
    }
    public function get_next_step_link() {
      $keys = array_keys( $this->steps );
      return add_query_arg( 'step', $keys[ array_search( $this->step, array_keys( $this->steps ) ) + 1 ], remove_query_arg( 'translation_updated' ) );
    }

    /**
		 * Setup Wizard Header
		 */
    public function setup_wizard_header() {
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>
  <head>
    <meta name="viewport" content="width=device-width" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title><?php _e( 'Pro Sites &rarr; WP Ultimo Migrator', 'wp-ultimo'); ?></title>
    <script type="text/javascript">
    var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
    var pagenow;
    </script>
    <?php do_action( 'admin_enqueue_scripts' ); ?>
    <?php do_action( 'admin_print_styles' ); ?>
    <?php do_action( 'admin_print_scripts' ); ?>
    <?php do_action( 'admin_head' ); ?>
  </head>
  <body class="wpultimo-setup wp-core-ui">
    <h1 id="wc-logo">
      <a href="https://wpultimo.com" target="_blank"><?php
                                           $image_url = WP_Ultimo()->get_asset('logo.png', 'img');
                                           if ( $image_url ) {
                                             $image = '<img class="site-logo" src="%s" alt="%s" style="width:%s; height:auto" />';
                                             printf(
                                               $image,
                                               $image_url,
                                               get_bloginfo( 'name' ),
                                               '200px'
                                             );
                                           } else { ?>
        <img src="<?php echo $this->plugin_url; ?>/images/logo.png" alt="Envato install wizard" /><?php
                                                  } ?></a>
    </h1>
    <?php
                                          }

    /**
		 * Setup Wizard Footer
		 */
    public function setup_wizard_footer() {
    ?>
    <?php if ( 'next_steps' === $this->step ) : ?>
    <a class="wc-return-to-dashboard" href="<?php echo esc_url( admin_url() ); ?>"><?php _e( 'Return to the WordPress Dashboard', 'wp-ultimo'); ?></a>
    <?php endif; ?>
  </body>
  <?php
      @do_action( 'admin_footer' ); // this was spitting out some errors in some admin templates. quick @ fix until I have time to find out what's causing errors.
      do_action( 'admin_print_footer_scripts' );
  ?>
</html>
<?php
    }

    /**
		 * Output the steps
		 */
    public function setup_wizard_steps() {
      $ouput_steps = $this->steps;
      array_shift( $ouput_steps );
?>
<ol class="wpultimo-setup-steps">
  <?php foreach ( $ouput_steps as $step_key => $step ) : ?>
  <li class="<?php
      $show_link = false;
      if ( $step_key === $this->step ) {
        echo 'active';
      } elseif ( array_search( $this->step, array_keys( $this->steps ) ) > array_search( $step_key, array_keys( $this->steps ) ) ) {
        echo 'done';
        $show_link = true;
      }
             ?>"><?php
      if ( $show_link ) {
    ?>
    <a href="<?php echo esc_url( $this->get_step_link( $step_key ) );?>"><?php echo esc_html( $step['name'] );?></a>
    <?php
      } else {
        echo esc_html( $step['name'] );
      }
    ?></li>
  <?php endforeach; ?>
</ol>
<?php
    }

    /**
		 * Output the content for the current step
		 */
    public function setup_wizard_content() {
      isset( $this->steps[ $this->step ] ) ? call_user_func( $this->steps[ $this->step ]['view'] ) : false;
    }

    /**
		 * Introduction step
		 */
    public function wu_setup_introduction() { 

      WP_Ultimo_PS_Migrator()->render('welcome', array(
        'wizard' => $this,
      ));
    
    } // end wu_setup_introduction;

    /**
     * Get settings
     * @return array get_settings
     */
    private function _get_settings_sections() {
      // Get all settings
      $allSettings = WU_Settings::get_sections();
      $network = array(
        'network_heading' => $allSettings['network']['fields']['network'],
        'enable_signup'   => $allSettings['network']['fields']['enable_signup'],
        'domain-mapping'  => $allSettings['domain_mapping']['fields']['enable_domain_mapping'],
        'active_gateway'  => $allSettings['gateways']['fields']['active_gateway'],
      );
      $settings = array_merge($network, $allSettings['general']['fields']);
      
      return $settings;

    } // end _get_settings_sections;

    /**
     * Display the settings step of this
     * @return array Array containing the pages
     */
    private function wu_setup_options() {

        /**
         * Initiate the Logger
         */
        WU_Logger::add('pro-sites-migrator', 'User confirms they read the step warning about the risks of the procedure and decided to move on.');
    
        WP_Ultimo_PS_Migrator()->render('domain-mapping', array(
          'wizard' => $this,
        ));
    
    } // end wu_setup_options;

    /**
     * Display the extra steps for sunrise.php and domains
     */
    public function wu_setup_checks() { ?>

      <h1><?php _e('Custom Domain Support', 'wp-ultimo'); ?></h1>

      <p><?php _e('We use the incredible <strong>Mercator</strong> by humanmade to handle the domain mapping in WP Ultimo. This is all done automatically via a interface with Mercator. Mercator is bundled with WP Ultimo already, so you don\'t need to install it. There are, however, a few extra steps to be taken if you want to enable custom domain support.', 'wp-ultimo'); ?></p>

      <h3>1. <?php _e('Copying sunrise.php', 'wp-ultimo'); ?></h3>

      <p><?php _e('You need to copy the <code>sunrise.php</code> from the <code>wp-ultimo</code> directory to your <code>wp-content</code> directory.', 'wp-ultimo'); ?></p>

      <p><button class="wu-ajax-button button" data-restore="false" data-url="<?php echo admin_url('admin-ajax.php?action=wu_upgrade_sunrise'); ?>"><?php _e('Copy Automatically', 'wp-ultimo'); ?></button>
      </p>

      <h3>2. <?php _e('Setting SUNRISE to true', 'wp-ultimo'); ?></h3>

      <p><?php _e("Now we need to let WordPress know it has to load our new sunrise.php. This should be done by adding <code>define('SUNRISE', true);</code> to your <code>wp-config.php</code> file.", 'wp-ultimo'); ?></p>

      <p style="border-radius: 3px; border: solid 1px #ccc; padding: 10px; display: block;"><?php _e("<strong>IMPORTANT:</strong> Be sure to add the <code>define('SUNRISE', true);</code> code <strong>ABOVE</strong> the <code>/* That's all, stop editing! Happy blogging. */</code> line of your <code>wp-config.php</code> file.", 'wp-ultimo'); ?>

      <form method="post">
      <p class="wpultimo-setup-actions step">
        <?php wp_nonce_field( 'wups-migrator' ); ?>
        <button type="submit" class="button-primary button button-large button-next" name="save_step"><?php _e( 'Check Configuration', 'wp-ultimo'); ?></button>
        <a href="<?php echo esc_url( $this->get_next_step_link() ); ?>" class="button button-large button-next"><?php _e( 'Skip this step', 'wp-ultimo'); ?></a>
      </p>
      </form>

    <?php } // end wu_setup_checks;

    /**
     * Display the extra steps for sunrise.php and domains
     */
    public function wu_setup_checks_save() { 

      check_admin_referer('wups-migrator');

      $extra_tip_message = '';

      $file_exists  = file_exists(WP_CONTENT_DIR.'/sunrise.php');
      $class_exists = class_exists('\Mercator\Mapping');

      // Check for the sunrise.php file on the wp_content directory
      $file_exists_message = $file_exists ? '<span class="success">OK</span>' : '<span class="error">NOT FOUND</span>';

      /**
       * @since  1.3.0 Checks if Logs Directory Exists
       */
      $logs_exists   = is_dir(WU_Logger::get_logs_folder());
      $logs_writable = is_writable(WU_Logger::get_logs_folder());

      $logs_exists_msg = $logs_exists ? '<span class="success">OK</span>' : '<span class="error">NOT FOUND</span>';
      $logs_writable_msg = $logs_writable ? '<span class="success">OK</span>' : '<span class="error">NOT WRITABLE</span>';

      /**
       * @since  1.2.2 Check for the existence of the Class
       */

      
      // Check sunrise constant
      $constant_set = defined('SUNRISE') ? SUNRISE : false;
      $constant = $constant_set ? '<span class="success">OK</span>' : '<span class="error">NOT FOUND</span>';
      
      if ($file_exists && $constant_set) {

        $file_exists_message = $class_exists ? '<span class="success">OK</span>' : '<span class="error">'. __('The file exists but it seems to be a different version of sunrise.php. Consider replacing the current sunrise.php on wp-content with the file on your wp-ultimo directory. Disregard this message if the SUNRISE constant is not set yet (step below).', 'wp-ultimo') .'</span>';

        $extra_tip_message = $class_exists ? '' : '<p style="border-radius: 3px; border: solid 1px #ccc; padding: 10px; display: block;">' . sprintf(__('<strong>Common Mistake:</strong><br>If you place the <code>%1$s</code> line below the <code>%2$s</code> line on the <code>wp-config.php</code> file, the system wil not be able to load the domain mapping functionality. Please, make sure you place the <code>%1$s</code> line <strong>ABOVE</strong> the <code>%2$s</code> line.', 'wp-ultimo'), 'define(\'SUNRISE\', true);', '/* That\'s all, stop editing! Happy blogging. */') . '</p>';

      } // end if;

      // global check
      $continue = $constant_set && $file_exists && $class_exists && $logs_exists && $logs_writable;

      if ($continue) {

        $extra_tip_message = '<div class="wu-hosting-notice" style="border-radius: 3px; border: solid 1px #ccc; padding: 10px; display: block;"><strong>'. strtoupper(__('Small note on Hosting Support for Domain Mapping:', 'wp-ultimo')) .'</strong><br><br>' . WU_Domain_Mapping::get_hosting_support_text() . '</div>';

      } // end if;

      ?>

      <h1><?php _e('Checking System Setup...', 'wp-ultimo'); ?></h1>

      <p>
        <strong><?php printf(__('Directory %s exists: ', 'wp-ultimo'), "<code>".WU_Logger::get_logs_folder()."</code>"); ?></strong> <?php echo $logs_exists_msg; ?>
        <br>
        <strong><?php printf(__('Directory %s is Writable: ', 'wp-ultimo'), "<code>".WU_Logger::get_logs_folder()."</code>"); ?></strong> <?php echo $logs_writable_msg; ?>
      </p>

      <p>
        <strong><?php _e('Sunrise.php file on the wp-content directory: ', 'wp-ultimo'); ?></strong> <?php echo $file_exists_message; ?>
        <br>
        <strong><?php _e('Sunrise constant set to true: ', 'wp-ultimo'); ?></strong> <?php echo $constant; ?>
      </p>

      <?php echo $extra_tip_message; ?>

      <form method="post">
      <p class="wpultimo-setup-actions step">
        <?php wp_nonce_field( 'wups-migrator' ); ?>

        <?php if ($continue) : ?>

          <a href="<?php echo esc_url( $this->get_next_step_link() ); ?>" class="button button-primary button-large button-large button-next"><?php _e( 'Continue', 'wp-ultimo'); ?></a>

        <?php else : ?>

          <button type="submit" class="button-primary button button-large button-next" name="save_step"><?php _e( 'Check Again', 'wp-ultimo'); ?></button>

          <a href="<?php echo esc_url( $this->get_next_step_link() ); ?>" class="button button-large button-next"><?php _e( 'Skip this step', 'wp-ultimo'); ?></a>

        <?php endif; ?>

      </p>
      </form>

    <?php } // end wu_setup_checks_save

    /**
     * Save logo & design options
     */
    public function wu_setup_options_save() {

      check_admin_referer('wups-migrator');

      $settings = WU_Settings::get_settings();
      
      // The post passed by the form
      $post = array_filter($_POST, function($key) {
      
        return in_array($key, array(
          'should_migrate_domain_mapping',
          'https_for_main_site',
          'https_for_subdomains',
          'https_for_mapped_domains',
        ));

      }, ARRAY_FILTER_USE_KEY);
      
      // Re-save the settings
      WP_Ultimo()->saveOption('wups_settings', $post);

      WU_Logger::add('pro-sites-migrator', '  ');
      WU_Logger::add('pro-sites-migrator', 'Domain Mapping Options:');

      foreach ($post as $setting => $value) {

        WU_Logger::add('pro-sites-migrator', sprintf('|-- Setting Domain Mapping Preference %s to %s', $setting, $value));

      } // end foreach;

      WU_Logger::add('pro-sites-migrator', 'Finished Setting Domain Mapping Preferences =)');

      wp_redirect( esc_url_raw( $this->get_next_step_link() ) );

      exit;

    } // end wu_setup_options_save;

    /**
     * Get the default content to be used, mostly our default Plans
     * @return array Array containing the pages
     */
    public function _plugins_get() {

      $plugins = WU_PS_Incompat_Plugins()->get_installed_incompat_plugins();

      foreach($plugins as $key => &$item) {

        $item = array(
          'title'            => $item['name'],
          'description'      => $item['desc'],
          'pending'          => __('Pending...', 'wp-ultimo'),
          'installing'       => sprintf(__('Deactivating %s...', 'wp-ultimo'), $item['name']),
          'success'          => __('Success.', 'wp-ultimo'),
          'skippable'        => $key == 'pro-sites/pro-sites.php',
          'install_callback' => array( $this,'_deactivate_plugin'),
          'args'             => $key,
        );

      } // end foreach;

      return $plugins;

    }

    /**
     * Get the default content to be used, mostly our default Plans
     * @return array Array containing the pages
     */
    public function _content_default_get() {

      $content = array();

      // Template Sites
      // $content['template-site'] = array(
      //   'title'            => __('Template Site', 'wp-ultimo'),
      //   'description'      => __('Create a simple site on your network, that you can use to create a template for future sign-ups. You can set a different template per plan, but you can also let your users select which template they want to use in the signup. If you already have a subsite that you would like to use as a template, you can uncheck this item.', 'wp-ultimo') .' '. sprintf('<a href="%s" target="_blank">%s</a>', WU_Links()->get_link('site-templates'), __('Read more about Site Templates', 'wp-ultimo')),
      //   'pending'          => __('Pending.', 'wp-ultimo'),
      //   'installing'       => __('Creating default template site.', 'wp-ultimo'),
      //   'success'          => __('Success.', 'wp-ultimo'),
      //   'install_callback' => array( $this,'_content_install_template_site'),
      // );
      $content['settings'] = array(
        'title'            => __('Settings', 'wp-ultimo'),
        'description'      => __('This step will take general settings like currency, API Keys, active gateways, and more from Pro Sites and use them to configure WP Ultimo.', 'wp-ultimo'),
        'pending'          => __('Pending...', 'wp-ultimo'),
        'installing'       => __('Installing Settings...', 'wp-ultimo'),
        'success'          => __('Success.', 'wp-ultimo'),
        'skippable'        => false,
        'install_callback' => array( $this,'_migrate_settings'),
      );

      $content['coupons'] = array(
        'title'            => __('Coupons', 'wp-ultimo'),
        'description'      => __('Both WP Ultimo and Pro Sites support coupon codes. Using this option, you can transform your existing coupons into WP Ultimo coupons.', 'wp-ultimo'),
        'pending'          => __('Pending...', 'wp-ultimo'),
        'installing'       => __('Migrating Coupons...', 'wp-ultimo'),
        'success'          => __('Success.', 'wp-ultimo'),
        'skippable'        => true,
        'install_callback' => array( $this,'_migrate_coupons'),
      );

      $content['plans'] = array(
        'title'            => __('Plans', 'wp-ultimo'),
        'description'      => __('Plans are what Pro Sites refers to levels on their system. This step will take Pro Sites levels, with all their characteristics (post quotas, upload quotas, allowed plugins and themes, prices, etc) and convert them into WP Ultimo Plans.', 'wp-ultimo'),
        'pending'          => __('Pending...', 'wp-ultimo'),
        'installing'       => __('Migrating Plans...', 'wp-ultimo'),
        'success'          => __('Success.', 'wp-ultimo'),
        'skippable'        => false,
        'install_callback' => array( $this,'_migrate_plans'),
      );

      $content['subscriptions'] = array(
        'title'            => __('Subscriptions', 'wp-ultimo'),
        'description'      => __('WP Ultimo will search for Pro Sites on the network and convert them to WP Ultimo Subscriptions.', 'wp-ultimo'),
        'pending'          => __('Pending...', 'wp-ultimo'),
        'installing'       => __('Creating Subscriptions...', 'wp-ultimo'),
        'success'          => __('Success.', 'wp-ultimo'),
        'skippable'        => false,
        'install_callback' => array( $this,'_migrate_subscriptions'),
      );

      $content['transactions'] = array(
        'title'            => __('Transactions', 'wp-ultimo'),
        'description'      => __('WP Ultimo will search for Pro Sites transactions and convert them to WP Ultimo transactions, attachhing them to the right subscriptions.', 'wp-ultimo'),
        'pending'          => __('Pending...', 'wp-ultimo'),
        'installing'       => __('Importing Transactions...', 'wp-ultimo'),
        'success'          => __('Success.', 'wp-ultimo'),
        'skippable'        => true,
        'install_callback' => array( $this,'_migrate_transactions'),
      );

      $migrator_settings = WP_Ultimo()->getOption('wups_settings', array(
        'should_migrate_domain_mapping' => 0,
      ));

      if ($migrator_settings['should_migrate_domain_mapping']) {

        $content['domain_mapping'] = array(
          'title'            => __('Mapped Domains', 'wp-ultimo'),
          'description'      => __('You opted to replace WPMU DEV\'s Domain Mapping with WP Ultimo\'s Domain Mapping functionality.', 'wp-ultimo'),
          'pending'          => __('Pending...', 'wp-ultimo'),
          'installing'       => __('Migrating Mappings...', 'wp-ultimo'),
          'success'          => __('Success.', 'wp-ultimo'),
          'skippable'        => false,
          'install_callback' => array( $this,'_migrate_domain_mappings'),
        );

      } // end if;

      // if (class_exists('Domainmap_Plugin')) {

        $content['blog_templates'] = array(
          'title'            => __('Blog Templates', 'wp-ultimo'),
          'description'      => sprintf(__('WP Ultimo has a similar feature called <a href="%s" target="_blank">Site Templates</a>. Checking this will allow the migrator to transform WPMU DEV\'s Blog Templates into WP Ultimo\'s Site Templates', 'wp-ultimo'), 'https://help.wpultimo.com/getting-started/getting-started-with-site-templates'),
          'pending'          => __('Pending...', 'wp-ultimo'),
          'installing'       => __('Migrating Blog Templates...', 'wp-ultimo'),
          'success'          => __('Success.', 'wp-ultimo'),
          'skippable'        => true,
          'install_callback' => array( $this,'_migrate_blog_templates'),
        );

      // } // end if;

      // $content['plugins'] = array(
      //   'title'            => __('Deactivating Plugins', 'wp-ultimo'),
      //   'description'      => __('Deactivate plugins that are no longer necessary and/or cause issues with WP Ultimo\'s signup', 'wp-ultimo'),
      //   'pending'          => __('Pending...', 'wp-ultimo'),
      //   'installing'       => __('Deactivating Plugins...', 'wp-ultimo'),
      //   'success'          => __('Success.', 'wp-ultimo'),
      //   'skippable'        => false,
      //   'install_callback' => array( $this,'_deactivating_plugins'),
      // );

      return $content;

    } // end _content_default_get;

    /**
		 * Page setup
		 */
    public function wu_setup_migrating_content() { 

      WP_Ultimo_PS_Migrator()->render('migrating', array(
        'wizard' => $this,
      ));
      
    }

    /**
		 * Page setup
		 */
    public function wu_setup_deactivating_plugins() { 

      WP_Ultimo_PS_Migrator()->render('plugins', array(
        'wizard' => $this,
      ));
      
    }


    public function ajax_content() {
      $content = $this->_content_default_get();

      if ( ! check_ajax_referer( 'wu_setup_nonce', 'wpnonce' ) || empty( $_POST['content'] ) && isset( $content[ $_POST['content'] ] ) ) {
        wp_send_json_error( array( 'error' => 1, 'message' => __( 'No content Found','wp-ultimo') ) );
      }

      $json = false;
      $this_content = $content[ $_POST['content'] ];

      if ( isset( $_POST['proceed'] ) ) {
        // install the content!

        if ( ! empty( $this_content['install_callback'] ) ) {
          if ( $result = call_user_func( $this_content['install_callback'] ) ) {
            $json = array(
              'done' => 1,
              'message' => $result['message'],
              'debug' => $result,
            );
          }
        }
      } else {

        $json = array(
          'url' => admin_url( 'admin-ajax.php' ),
          'action' => 'wu_setup_content',
          'proceed' => 'true',
          'content' => $_POST['content'],
          '_wpnonce' => wp_create_nonce( 'wu_setup_nonce' ),
          'message' => $this_content['installing'],
        );
      }

      if ( $json ) {
        $json['hash'] = md5( serialize( $json ) ); // used for checking if duplicates happen, move to next plugin
        wp_send_json( $json );
      } else {
        wp_send_json( array( 'error' => 1, 'message' => __( 'Error','wp-ultimo') ) );
      }

      exit;

    }

    public function ajax_deactivate_plugins() {
      $content = $this->_plugins_get();

      if ( ! check_ajax_referer( 'wu_setup_nonce', 'wpnonce' ) || empty( $_POST['content'] ) && isset( $content[ $_POST['content'] ] ) ) {
        wp_send_json_error( array( 'error' => 1, 'message' => __( 'No content Found','wp-ultimo') ) );
      }

      $json = false;
      $this_content = $content[ $_POST['content'] ];

      if ( isset( $_POST['proceed'] ) ) {
        // install the content!

        if ( ! empty( $this_content['install_callback'] ) ) {
          if ( $result = call_user_func( $this_content['install_callback'], $this_content['args'] ) ) {
            $json = array(
              'done' => 1,
              'message' => $result['message'],
              'debug' => $result,
            );
          }
        }
      } else {

        $json = array(
          'url' => admin_url( 'admin-ajax.php' ),
          'action' => 'wu_deactivate_plugins',
          'proceed' => 'true',
          'content' => $_POST['content'],
          '_wpnonce' => wp_create_nonce( 'wu_setup_nonce' ),
          'message' => $this_content['installing'],
        );
      }

      if ( $json ) {
        $json['hash'] = md5( serialize( $json ) ); // used for checking if duplicates happen, move to next plugin
        wp_send_json( $json );
      } else {
        wp_send_json( array( 'error' => 1, 'message' => __( 'Error','wp-ultimo') ) );
      }

      exit;

    }

    private function _import_wordpress_xml_file( $xml_file_path ) {
      global $wpdb;

      if ( ! defined( 'WP_LOAD_IMPORTERS' ) ) { define( 'WP_LOAD_IMPORTERS', true ); }

      // Load Importer API
      require_once ABSPATH . 'wp-admin/includes/import.php';

      if ( ! class_exists( 'WP_Importer' ) ) {
        $class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
        if ( file_exists( $class_wp_importer ) ) {
          require $class_wp_importer;
        }
      }

      if ( ! class_exists( 'WP_Import' ) ) {
        $class_wp_importer = __DIR__ .'/importer/wordpress-importer.php';
        if ( file_exists( $class_wp_importer ) ) {
          require $class_wp_importer; }
      }

      if ( class_exists( 'WP_Import' ) ) {
        require_once __DIR__ .'/importer/wpultimo-content-import.php';
        $wp_import = new wu_content_import();
        $wp_import->fetch_attachments = true;
        ob_start();
        $wp_import->import( $xml_file_path );
        $message = ob_get_clean();
        return array( $wp_import->check(),$message );
      }
      return false;
    }

    /**
     * Import the plans, if the user chooses to do so
     * @return boolean If the importing was successful;
     */
    private function _content_install_plans() {
      return $this->_import_wordpress_xml_file( __DIR__ .'/content/plans.xml');
    }

    /**
     * Create the new template blog
     * @return boolean If the creation was successful;
     */
    private function _content_install_template_site() {

      

    }

    private function _migrate_settings() {

      sleep(1);

      $settings = WU_PS_Settings_Migrator()->get_ps_settings();

      //$templates = WU_PS_Settings_Migrator()->get_ps_templates();
      //$results = WU_PS_Settings_Migrator()->convert_to_wu_templates($templates);


      $results = WU_PS_Settings_Migrator()->convert_to_wu_settings($settings);

      return array(
        'message' => sprintf(__('%s settings installed successfully.', 'wups-migrator'), count($results['updated']))
      );

    }

    private function _migrate_blog_templates() {

      sleep(1);

      $blog_templates = WU_PS_Settings_Migrator()->get_ps_templates();

      $results = WU_PS_Settings_Migrator()->convert_to_wu_templates($blog_templates);

      return array(
        'message' => sprintf(__('%s blog templates migrated successfully.', 'wups-migrator'), count($results['updated']))
      );

    }

    private function _migrate_coupons() {

      sleep(1);

      $coupons = WU_PS_Coupon_Migrator()->get_ps_coupons();

      $results = WU_PS_Coupon_Migrator()->convert_to_wu_coupons($coupons);

      $message = $results['success'] 
        ? sprintf(__('%s coupons created, %s updated.', 'wups-migrator'), count($results['added']), count($results['updated']))
        : __('Failed.', 'wups-migrator');
      
      return array(
        'message' => $message,
      );

    }

    private function _migrate_plans() {

      sleep(1);

      $plans = WU_PS_Plan_Migrator()->get_ps_plans();

      $results = WU_PS_Plan_Migrator()->convert_to_wu_plans($plans);
      
      $message = $results['success'] 
        ? sprintf(__('%s plans created, %s updated.', 'wups-migrator'), count($results['added']), count($results['updated']))
        : __('Failed.', 'wups-migrator');
      
      return array(
        'message' => $message,
      );

    }

    private function _migrate_subscriptions() {

      $sites = WU_PS_Subscription_Migrator()->get_all_pro_sites();

      if ($sites < 20) {

        sleep(1);

      } // end if;

			$results = WU_PS_Subscription_Migrator()->convert_pro_sites_to_wp_ultimo_subscriptions($sites);
      
      $message = $results['success'] 
        ? sprintf(__('%s subscriptions created, %s updated.', 'wups-migrator'), count($results['added']), count($results['updated']))
        : __('Failed.', 'wups-migrator');
      
      return array(
        'message' => $message,
      );

    }

    private function _migrate_transactions() {

      $transactions = (WU_PS_Subscription_Migrator()->get_pro_sites_transactions());

      if ($transactions < 20) {

        sleep(1);

      } // end if;

			$results = WU_PS_Subscription_Migrator()->convert_transactions_to_wp_ultimo($transactions);
      
      $message = $results['success'] 
        ? sprintf(__('%s transactions created, %s skipped.', 'wups-migrator'), count($results['added']), count($results['updated']))
        : __('Failed.', 'wups-migrator');
      
      return array(
        'message' => $message,
      );

    }

    /**
     * Returns an array of all the mapped domains currently on the network
     *
     * @since 1.6.0
     * @return array
     */
    public function get_all_mapped_domains() {

      global $wpdb;

      // Prepare the query
      $query = "SELECT * FROM {$wpdb->base_prefix}domain_mapping";

      // Suppress errors in case the table doesn't exist
      $suppress = $wpdb->suppress_errors();
      $mappings = $wpdb->get_results($query);
      $wpdb->suppress_errors( $suppress );
      
      return $mappings;

    } // end get_all_mapped_domains;

    private function _migrate_domain_mappings() {

      $added = array();

      $updated = array();

      $failed = array();

      WU_Logger::add('pro-sites-migrator', '  ');
		  WU_Logger::add('pro-sites-migrator', 'Migrating Domain Mappings:');

      $settings = WP_Ultimo()->getOption('wups_settings', array(
        'should_migrate_domain_mapping' => 0,
      ));

      if (!$settings['should_migrate_domain_mapping']) {

        WU_Logger::add('pro-sites-migrator', 'User decided to skip domain mapping migration. Skipping it.');

        return;

      } // end if;

      /**
       * Turn domain mapping on
       */
      WU_Settings::save_setting('enable_domain_mapping', true);
      WU_Settings::save_setting('custom_domains', true);

      /**
       * Set settings for HTTPS
       */
      WU_Settings::save_setting('force_admin_https', isset($settings['https_for_main_site']));
      WU_Settings::save_setting('force_subdomains_https', isset($settings['https_for_subdomains']));
      WU_Settings::save_setting('force_mapped_https', isset($settings['https_for_mapped_domains']));

      $all_mappings = $this->get_all_mapped_domains();

      foreach ($all_mappings as $mapping) {

        $status = update_blog_option($mapping->blog_id, 'wu_custom-domain', $mapping->domain);

        if ($status) {

          WU_Logger::add('pro-sites-migrator', sprintf('|-- Domain %s migrated successfully.', $mapping->domain));

          $added[] = $mapping;

        } else {

          WU_Logger::add('pro-sites-migrator', sprintf('|-- Domain %s already existed. Skipping it.', $mapping->domain));
          
          $updated[] = $mapping;
          
        } // end if;

      } // end foreach;

      $message = true
        ? sprintf(__('%s domain mappings created, %s skipped.', 'wups-migrator'), count($added), count($updated))
        : __('Failed.', 'wups-migrator');
      
      return array(
        'message' => $message,
      );

    }

    private function _deactivate_plugin($plugin) {

      sleep(1);			

      return array(
        'message' => 
        WU_PS_Incompat_Plugins()->deactivate_plugins(array($plugin)) ? sprintf(__('Plugin deactivated.', 'wups-migrator')) : sprintf(__('Error deactivating plugin.', 'wups-migrator'))
      );

    }

    /**
     * This displays the help and activation step
     */
    public function wu_setup_risks() { 

      /**
       * Initiate the Logger
       */
      WU_Logger::add('pro-sites-migrator', '============ STARTING NEW MIGRATION ============');

      WP_Ultimo_PS_Migrator()->render('risks', array(
        'wizard' => $this,
      ));

    }

    /**
		 * Final step
		 */
    public function wu_setup_ready() {

      /**
       * End the Logger
       */
      WU_Logger::add('pro-sites-migrator', '============ END MIGRATION ============');
      WU_Logger::add('pro-sites-migrator', '   ');
    
      WP_Ultimo_PS_Migrator()->render('done', array(
        'wizard' => $this,
      ));
    
    }

    /**
		 * @param $array1
		 * @param $array2
		 *
		 * @return mixed
		 *
		 *
		 * @since    1.1.4
		 */
    private function _array_merge_recursive_distinct( $array1, $array2 ) {
      $merged = $array1;
      foreach ( $array2 as $key => &$value ) {
        if ( is_array( $value ) && isset ( $merged [ $key ] ) && is_array( $merged [ $key ] ) ) {
          $merged [ $key ] = $this->_array_merge_recursive_distinct( $merged [ $key ], $value );
        } else {
          $merged [ $key ] = $value;
        }
      }
      return $merged;
    }

    /**
		 * Helper function
		 * Take a path and return it clean
		 *
		 * @param string $path
		 *
		 * @since    1.1.2
		 */
    public static function cleanFilePath( $path ) {
      $path = str_replace( '', '', str_replace( array( "\\", "\\\\" ), '/', $path ) );
      if ( $path[ strlen( $path ) - 1 ] === '/' ) {
        $path = rtrim( $path, '/' );
      }
      return $path;
    }

    public function is_submenu_page(){
      return ( $this->parent_slug == '' ) ? false : true;
    }
  }

} // if !class_exists

/**
 * Loads the main instance of WP_Ultimo_Pro_Sites_Migrator to have
 * ability extend class functionality
 *
 * @since 1.1.1
 * @return object WP_Ultimo_Pro_Sites_Migrator
 */
add_action('init', 'WP_Ultimo_Pro_Sites_Migrator', 10);

if (!function_exists('WP_Ultimo_Pro_Sites_Migrator')) :

function WP_Ultimo_Pro_Sites_Migrator() {

  WP_Ultimo_Pro_Sites_Migrator::get_instance();

}

endif;
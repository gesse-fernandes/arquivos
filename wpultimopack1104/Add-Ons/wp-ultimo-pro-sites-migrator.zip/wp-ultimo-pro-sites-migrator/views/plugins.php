<h1><?php _e( 'Plugins', 'wp-ultimo'); ?></h1>
<form method="post">
  <p><?php printf( __( 'Some of WPMU DEV multisite plugins are not compatible with WP Ultimo\'s sign-up flow. Keeping them active will cause issues, so this step is all about deactivating them for you.', 'wp-ultimo'), '<a href="' . esc_url( admin_url( 'edit.php?post_type=page' ) ) . '" target="_blank">', '</a>' ); ?></p>
  <p><?php printf( __( 'Here are the troublemakers:', 'wp-ultimo'), '<a href="' . esc_url( admin_url( 'edit.php?post_type=page' ) ) . '" target="_blank">', '</a>' ); ?></p>
  <table class="wpultimo-setup-pages" cellspacing="0">
    <thead>
      <tr>
        <td class="check"> </td>
        <th class="item"><?php _e( 'Item', 'wp-ultimo'); ?></th>
        <th class="description"><?php _e( 'Description', 'wp-ultimo'); ?></th>
        <th class="status"><?php _e( 'Status', 'wp-ultimo'); ?></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ( $wizard->_plugins_get() as $slug => $default ) {  ?>
      <tr class="envato_default_content" data-content="<?php echo esc_attr( $slug );?>">
        <td>
          <input <?php disabled(!$default['skippable']); ?> type="checkbox" name="default_content[pages]" class="envato_default_content" id="default_content_<?php echo esc_attr( $slug );?>" value="1" checked>
        </td>
        <td><label for="default_content_<?php echo esc_attr( $slug );?>"><?php echo $default['title']; ?></label></td>
        <td class="description"><?php echo $default['description']; ?></td>
        <td class="status"> <span><?php echo $default['pending'];?></span> <div class="spinner"></div></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>

  <br>

  <!-- <p><?php _e( 'Detailed results will be shown on the last step.', 'wp-ultimo'); ?></p> -->

  <p class="wpultimo-setup-actions step">
    <a href="<?php echo esc_url( $wizard->get_next_step_link() ); ?>" class="button-primary button button-large button-next" data-callback="deactivate_plugins"><?php _e( 'Deactivate Plugins', 'wp-ultimo'); ?></a>
    <a href="<?php echo esc_url( $wizard->get_next_step_link() ); ?>" class="button button-large button-next"><?php _e( 'Skip this step', 'wp-ultimo'); ?></a>
    <?php wp_nonce_field( 'wpultimo-setup' ); ?>
  </p>
</form>
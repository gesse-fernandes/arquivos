
<h1><?php _e('Domain Mapping', 'wp-ultimo'); ?></h1>
<form method="post">
  <p><?php _e('If you are using WPMU DEV\'s Domain Mapping plugin to handle your mapped domains you can continue to do so, as their plugin is completely compatible with WP Ultimo. However, if you wish to switch to WP Ultimo\'s Domain Mapping solution, this migrator can help you with the heavy-lifting.', 'wp-ultimo'); ?></p>
  <p><?php _e('If you are not using WPMU DEV\'s Domain Mapping plugin, you can skip this step.', 'wp-ultimo'); ?></p>
  
  <table class="wpultimo-setup-pages" cellspacing="0">
    <tbody>

    <tr>
				<th scope="row"><?php _e('Domain Mapping', 'wp-ultimo'); ?></th>
								<td>
					<fieldset>
					<legend class="screen-reader-text"><?php _e('Domain Mapping', 'wp-ultimo'); ?></legend>
					<label><input v-model="should_migrate_domain_mapping" name="should_migrate_domain_mapping" type="radio" id="registration1" value="0"> <?php _e('I want to continue to use WPMU DEV Domain Mapping.', 'wp-ultimo'); ?></label><br>
					<label><input v-model="should_migrate_domain_mapping" name="should_migrate_domain_mapping" type="radio" id="registration2" value="1"> <?php _e('I want to migrate to WP Ultimo Domain Mapping.', 'wp-ultimo'); ?></label><br>
										</fieldset>
				</td>
			</tr>
    <tr v-cloak v-if="should_migrate_domain_mapping == 1">
				<th scope="row"><?php _e('SSL Settings', 'wp-ultimo'); ?></th>
								<td>
					<fieldset>
          <legend class="screen-reader-text"><?php _e('Domain Mapping', 'wp-ultimo'); ?></legend>
          
          <label><input v-model="https_for_main_site" name="https_for_main_site" type="checkbox" id="registration1" value="0"> <?php _e('HTTPS is active on my main site', 'wp-ultimo'); ?></label><br>

          <?php if (is_subdomain_install()) : ?>
          <label><input v-model="https_for_subdomains" name="https_for_subdomains" type="checkbox" id="registration1" value="0"> <?php _e('HTTPS is active for my sub-domains', 'wp-ultimo'); ?></label><br>
          <?php endif; ?>

          <label><input v-model="https_for_mapped_domains" name="https_for_mapped_domains" type="checkbox" id="registration1" value="0"> <?php _e('HTTPS is active on my mapped domains', 'wp-ultimo'); ?></label><br>
          
          
										</fieldset>
				</td>
			</tr>

    </tbody>
  </table>

  <br>

  <p class="wpultimo-setup-actions step">
    <?php wp_nonce_field( 'wups-migrator' ); ?>
    <button type="submit" class="button-primary button button-large button-next" name="save_step"><?php _e( 'Continue', 'wp-ultimo'); ?></button>
    <a href="<?php echo esc_url( $wizard->get_next_step_link() ); ?>" class="button button-large button-next"><?php _e( 'Skip this step', 'wp-ultimo'); ?></a>
    <small style="font-weight: 400;"><?php _e('No action will be taken yet. You will have to confirm the migration on the Migration step.', 'wp-ultimo'); ?></small>
  </p>
</form>

<script>
new Vue({
  el: ".wpultimo-setup-pages",
  data: {
    should_migrate_domain_mapping: 0,
    https_for_main_site: 1,
    https_for_subdomains: 0,
    https_for_mapped_domains: 0,
  }
})
</script>
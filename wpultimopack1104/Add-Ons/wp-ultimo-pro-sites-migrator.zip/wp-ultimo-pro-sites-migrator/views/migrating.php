<h1><?php _e( 'Migrating', 'wp-ultimo'); ?></h1>
<form method="post">
  <p><?php printf( __( 'This is the step that will actually handle the migrations. Some of the migrations are skippable (uncheck the box to skip them), others are mandatory.', 'wp-ultimo'), '<a href="' . esc_url( admin_url( 'edit.php?post_type=page' ) ) . '" target="_blank">', '</a>' ); ?></p>
  <table class="wpultimo-setup-pages" cellspacing="0">
    <thead>
      <tr>
        <td class="check"> </td>
        <th class="item"><?php _e( 'Item', 'wp-ultimo'); ?></th>
        <th class="description"><?php _e( 'Description', 'wp-ultimo'); ?></th>
        <th class="status"><?php _e( 'Status', 'wp-ultimo'); ?></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ( $wizard->_content_default_get() as $slug => $default ) {  ?>
      <tr class="envato_default_content" data-content="<?php echo esc_attr( $slug );?>">
        <td>
          <input <?php disabled(!$default['skippable']); ?> type="checkbox" name="default_content[pages]" class="envato_default_content" id="default_content_<?php echo esc_attr( $slug );?>" value="1" checked>
        </td>
        <td><label for="default_content_<?php echo esc_attr( $slug );?>"><?php echo $default['title']; ?></label></td>
        <td class="description"><?php echo $default['description']; ?></td>
        <td class="status"> <span><?php echo $default['pending'];?></span> <div class="spinner"></div></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>

  <br>

  <!-- <p><?php _e( 'Detailed results will be shown on the last step.', 'wp-ultimo'); ?></p> -->

  <p class="wpultimo-setup-actions step">
    <a href="<?php echo esc_url( $wizard->get_next_step_link() ); ?>" class="button-primary button button-large button-next" data-callback="install_content"><?php _e( 'Start Migration', 'wp-ultimo'); ?></a>
    <a href="<?php echo esc_url( $wizard->get_next_step_link() ); ?>" class="button button-large button-next"><?php _e( 'Skip this step', 'wp-ultimo'); ?></a>
    <?php wp_nonce_field( 'wpultimo-setup' ); ?>
  </p>
</form>
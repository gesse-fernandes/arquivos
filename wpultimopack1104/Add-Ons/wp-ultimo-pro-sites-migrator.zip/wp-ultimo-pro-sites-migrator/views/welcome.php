<div style="text-align: center;">

    <p>
        <img style="width: 400px; height: auto;" alt="<?php _e('Pro Sites -> WP Ultimo', 'wp-ultimo'); ?>" src="<?php echo WP_Ultimo_PS_Migrator()->get_asset('animation.gif', 'img'); ?>">
    </p>

    <h1><?php _e('Welcome to the Pro Sites &rarr; WP Ultimo Migrator!', 'wp-ultimo'); ?></h1>

    <p><?php _e('First of all, Thank you for choosing the WP Ultimo plugin =)', 'wp-ultimo'); ?></p>
    <p><?php _e('This tool was designed with the goal of migrating a premium network build on-top of WPMU Dev\'s Pro Sites to WP Ultimo in mind. We know how scary this might be, but this migrator should be able to do 99% of the heavy-lifting for you in an automated way, to minimize the potential for errors and reduce downtime on your network to a minimum.', 'wp-ultimo'); ?></p>

    <p><strong><?php printf(__('WP Ultimo and Pro Sites are different products, with different paths, goals, and implementations. Although there is a enourmous feature overlap, you will lose some features, gain others, and have to learn how to manage your network the WP Ultimo way. It is important that you are <a href="%s" target="_blank">aware of these differences</a> before moving on so you can make an informed decision.', 'wp-ultimo'), 'https://wpultimo.com/2019/05/10/hey-there-pro-sites-user/'); ?></strong></p>

    <h2><?php _e( 'Ready to go?', 'wp-ultimo'); ?></h2>

    <?php if (class_exists('ProSites')) : ?>

    <p class="wpultimo-setup-actions step">
    <a href="<?php echo esc_url( $wizard->get_next_step_link() ); ?>"
        class="button-primary button button-large button-next"><?php _e('Let\'s Go!', 'wp-ultimo'); ?></a>
    <a href="<?php echo esc_url( wp_get_referer() && !strpos( wp_get_referer(), 'update.php' ) ? wp_get_referer() : admin_url( '' ) ); ?>"
        class="button button-large"><?php _e('Not right now', 'wp-ultimo'); ?></a>
    </p>

    <?php else : ?>

    <p class="wpultimo-setup-actions step">
    
        <a href="<?php echo esc_url( network_admin_url( 'plugins.php' ) ); ?>"
        class="button button-large"><?php _e('Go to Plugins', 'wp-ultimo'); ?></a>
        <small style="font-weight: 400;"><?php _e('Pro Sites needs to be active for the migrator to work properly.', 'wp-ultimo'); ?></small>
    </p>

    <?php endif; ?>
</div>

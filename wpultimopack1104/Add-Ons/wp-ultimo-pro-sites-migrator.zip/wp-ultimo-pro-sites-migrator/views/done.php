<!-- <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://wpultimo.com" data-text="<?php echo esc_attr('I just created my own premium WordPress site network with #wpultimo'); ?>" data-via="arindoduque" data-size="large">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script> -->

<h1><?php _e( 'Congratulations! The Migration is Done!', 'wp-ultimo'); ?></h1>

<p><?php _e( 'No major errors were detected during the migration process! You should be good to go now!', 'wp-ultimo'); ?></p>

<!-- <p>You can see some of our other premium plugins visiting <a href="http://nextpress.co" target="_blank">our portfolio.</a> <br/>Follow <a  href="https://twitter.com/arindoduque" target="_blank">@arindoduque</a> on Twitter to see updates and news. Thanks! </p> -->

<div class="wpultimo-setup-next-steps">
  <div class="wpultimo-setup-next-steps-first">
    <h2><?php _e( 'Next Steps', 'wp-ultimo'); ?></h2>
    <ul>
      <!-- <li class="setup-product"><a class="button button-primary button-large" href="https://twitter.com/arindoduque" target="_blank"><?php _e( 'Follow @arindoduque on Twitter', 'wp-ultimo'); ?></a></li> -->
      <li class="setup-product"><a class="button button-next button-large" href="<?php echo esc_url( network_admin_url() ); ?>"><?php _e( 'Go back to the Dashboard &rarr;', 'wp-ultimo'); ?></a></li>
    </ul>
  </div>
  <div class="wpultimo-setup-next-steps-last">
    <h2><?php _e( 'Or...', 'wp-ultimo'); ?></h2>
    <ul>
      <li class="documentation"><a href="<?php echo esc_url(network_admin_url('admin.php?page=wp-ultimo-system-info&wu-tab=logs&file=' . urlencode(WU_Logger::get_logs_folder()) . 'pro-sites-migrator.log&action=see')); ?>" target="_blank"><?php _e( 'Read the migration Logs', 'wp-ultimo'); ?></a></li>
    </ul> 
  </div>
</div> 
<h1><?php _e('What will this Migrator do?', 'wp-ultimo'); ?></h1>

<p><?php _e('Simply put, it will read Pro Sites data from your network, translate it into data WP Ultimo can understand, and save the new data so WP Ultimo can use it.', 'wp-ultimo'); ?></p>
<!-- 
<h3><?php _e('What will be migrated?', 'wp-ultimo'); ?></h3> -->

<h1><?php _e('Understanding the Risks', 'wp-ultimo'); ?></h1>

<p><?php _e('Migrators are not an easy piece of software to get to work right. Despite testing this as much as possible, there is still a chance it can go wrong somehow.', 'wp-ultimo'); ?> <?php _e('Because of that, it is important that you understand the risks involved.', 'wp-ultimo'); ?></p>

<p><?php _e('Here are a few recommendations before you go ahead and run the migrator:', 'wp-ultimo'); ?></p>

<ul class="support-available">
  <li><?php _e('<strong>Create a backup</strong> of your Network before moving on;', 'wp-ultimo'); ?></li>
  <li><?php _e('If possible, run the migrator on a staging environment first;', 'wp-ultimo'); ?></li>
</ul>

<br>

<p><?php _e('Not following the above recommendations can result in:', 'wp-ultimo'); ?></p>

<ul class="support-unavailable">
  <li><?php _e('Damages to your multisite network that you will not be able to undo without a backup.', 'wp-ultimo'); ?></li>
</ul>

<br>

<table class="wpultimo-setup-pages" cellspacing="0">
    <tbody>

    <tr>
        <th scope="row">
          <?php _e('Check this box to move to the next step', 'wp-ultimo'); ?><br>
          <small style="font-weight: 400;"><?php _e('No action will be taken yet', 'wp-ultimo'); ?></small>
      </th>
								<td>
					<fieldset>
					<legend class="screen-reader-text"><?php _e('Check this box to move to the next step', 'wp-ultimo'); ?></legend>
					<label><input v-model="confirmed" name="should_migrate_domain_mapping" type="checkbox" id="regision1" value="1"> <?php _e('I understand the risks involved and took the appropriate steps to mitigate them.', 'wp-ultimo'); ?></label><br>
										</fieldset>
				</td>
			</tr>
</tbody>
  </table>

  <br>


<p v-cloak v-if="confirmed" class="wpultimo-setup-actions step">
  <a  href="<?php echo esc_url( $wizard->get_next_step_link() ); ?>" class="button button-primary button-large button-next"><?php _e( 'Continue', 'wp-ultimo'); ?></a>
  <?php wp_nonce_field( 'wpultimo-setup' ); ?>
  <small style="font-weight: 400;"><?php _e('No action will be taken yet. You will have to confirm the migration on the Migration step.', 'wp-ultimo'); ?></small>
</p>


<script>
new Vue({
  el: ".wpultimo-setup-content",
  data: {
    confirmed: false,
  }
})
</script>
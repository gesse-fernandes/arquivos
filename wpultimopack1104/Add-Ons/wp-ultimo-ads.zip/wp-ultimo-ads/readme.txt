=== WP Ultimo: Ads Injector ===
Contributors: aanduque
Requires at least: 4.9

Inject Ads on some of your plans directly from your plan's edit page! Feel free to provide feedback on the forums at https://docs.wpultimo.com/community/

== Description ==

WP Ultimo: Ads Injector

Inject Ads on some of your plans directly from your plan's edit page! Feel free to provide feedback on the forums at https://docs.wpultimo.com/community/

== Installation ==

1. Upload 'wp-ultimo-ads' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in your WordPress Network Admin

== Changelog ==

Version 1.0.2 - 04/05/2019

* Added: Content now supports shortcode processing;

Version 1.0.1 - 07/12/2018

* Fixed: Updated the metadata URL for updates;

Version 1.0.0 - 15/08/2018

* Added: Fixed Language files;

0.0.1 - Initial Beta Release
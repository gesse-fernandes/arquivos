=== WP Ultimo: AffiliateWP Integration ===
Contributors: aanduque, Aaron Prins
Requires at least: 4.4
Tested up to: 5.0.3
Requires PHP: 5.6
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Use the powerful AffiliateWP to grow the client base of your Ultimo Network!

Thanks to Aron Prins (www.aronprins.com) with the help with this integration.

== Description ==

WP Ultimo: AffiliateWP Integration

Use the powerful AffiliateWP to grow the client base of your Ultimo Network!

== Installation ==

1. Upload 'wp-ultimo-affiliatewp' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in your WordPress main site
3. Follow the step by step Wizard to set the plugin up

WP Ultimo: AffiliateWP Integration should be activated in the main site alongside with AffiliateWP.

== Changelog ==

Version 1.1.4 - 22/08/2019

* Improved: The AffiliateWP Integration now supports commissions on setup fees;
* Fixed: Reference column not linking to the WP Ultimo subscription referred;

Version 1.1.3 - 12/03/2019

* Improved: Added a notice letting admins know that AffiliateWP is a requirement;

Version 1.1.2 - 15/12/2018

* Improved: New update URL for the add-on updater;
* Fixed: Added support to AffiliateWP new methods of referral calculation;

Version 1.1.1 - 15/08/2018

* Fixed: Added a check to SSL connection, to avoid not converting visits on refused connections;
* Improved: Now we load tracking scripts to the register page, for when the user reaches it directly;

Version 1.1.0 - 03/05/2018

* Fixed: Various bugs;
* Added: Support to recurring referrals;

1.0.0 - Initial Release
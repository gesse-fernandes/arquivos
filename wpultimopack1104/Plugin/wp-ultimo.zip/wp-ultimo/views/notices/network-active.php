<div class="updated">
  <p><?php printf(__('WP Ultimo needs to be network active to run properly. You can "Network Activate" it <a href="%s">here</a>', 'wp-ultimo'), network_admin_url('plugins.php')); ?></p>
</div>
<table id="wu-sites-list" width="100%" class="widefat striped wu-sites-list">
  <tr>
    <td colspan="2" class="text-center" style="vertical-align: middle;">
      <span class="description"><?php _e('Select a user above to see the site list.', 'wp-ultimo'); ?></span>
    </td>
  </tr>
</table>
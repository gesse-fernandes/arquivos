<?php
$name='DejaVuSansCondensed';
$type='TTF';
$desc=array (
  'Ascent' => 928.0,
  'Descent' => -236.0,
  'CapHeight' => 928.0,
  'Flags' => 4,
  'FontBBox' => '[-918 -463 1614 1232]',
  'ItalicAngle' => 0.0,
  'StemV' => 87.0,
  'MissingWidth' => 540.0,
);
$up=-63;
$ut=44;
$ttffile=WP_Ultimo()->path('inc/invoicer/inc/tfpdf/font/unifont/DejaVuSansCondensed.ttf');
$originalsize=680264;
$fontkey='dejavu';
?>
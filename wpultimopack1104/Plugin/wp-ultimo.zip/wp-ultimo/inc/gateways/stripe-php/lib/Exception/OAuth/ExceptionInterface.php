<?php

namespace WU_Stripe\Exception\OAuth;

/**
 * The base interface for all Stripe OAuth exceptions.
 */
interface ExceptionInterface extends \WU_Stripe\Exception\ExceptionInterface
{
}

<?php

namespace WU_Stripe\Exception;

class UnexpectedValueException extends \UnexpectedValueException implements ExceptionInterface
{
}
